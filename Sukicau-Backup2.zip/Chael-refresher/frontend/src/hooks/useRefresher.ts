import { useState, useCallback } from 'react';
import { AccountDetails, RefreshResponse, ToastMessage } from '../types';

export const useRefresher = () => {
  const [inputCookie, setInputCookie] = useState<string>('');
  const [refreshedCookie, setRefreshedCookie] = useState<string>('');
  const [mode, setMode] = useState<'basic' | 'detailed'>('basic');
  const [logoutAll, setLogoutAll] = useState<boolean>(false);
  const [loading, setLoading] = useState<boolean>(false);
  const [details, setDetails] = useState<AccountDetails | null>(null);
  const [toasts, setToasts] = useState<ToastMessage[]>([]);
  const [isCopied, setIsCopied] = useState<boolean>(false);

  const addToast = useCallback((type: ToastMessage['type'], title: string, message?: string) => {
    const id = Math.random().toString(36).substring(2, 9);
    setToasts(prev => [...prev, { id, type, title, message }]);
    setTimeout(() => {
      setToasts(prev => prev.filter(t => t.id !== id));
    }, 3500);
  }, []);

  const dismissToast = useCallback((id: string) => {
    setToasts(prev => prev.filter(t => t.id !== id));
  }, []);

  const clearInput = useCallback(() => {
    setInputCookie('');
  }, []);

  const pasteCookie = useCallback(async () => {
    try {
      if (navigator.clipboard && navigator.clipboard.readText) {
        const text = await navigator.clipboard.readText();
        if (text) {
          setInputCookie(text.trim());
          addToast('info', 'Pasted from clipboard');
        }
      }
    } catch {
      addToast('warning', 'Clipboard access denied', 'Please paste manually into the field.');
    }
  }, [addToast]);

  const copyCookie = useCallback(async () => {
    if (!refreshedCookie) return;
    try {
      if (navigator.clipboard && window.isSecureContext) {
        await navigator.clipboard.writeText(refreshedCookie);
      } else {
        const el = document.createElement('textarea');
        el.value = refreshedCookie;
        document.body.appendChild(el);
        el.select();
        document.execCommand('copy');
        document.body.removeChild(el);
      }
      setIsCopied(true);
      addToast('success', 'Copied to clipboard');
      setTimeout(() => setIsCopied(false), 2000);
    } catch {
      addToast('error', 'Failed to copy cookie');
    }
  }, [refreshedCookie, addToast]);

  const refresh = useCallback(async () => {
    const cookie = inputCookie.trim();
    if (!cookie) {
      addToast('warning', 'Cookie Required', 'Please paste your .ROBLOSECURITY cookie first.');
      return;
    }

    setLoading(true);
    setDetails(null);

    try {
      const response = await fetch('/api/index.php', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          cookie,
          logout_all: logoutAll,
          detailed: mode === 'detailed'
        })
      });

      const data: RefreshResponse = await response.json();

      if (data.success && data.cookie) {
        setRefreshedCookie(data.cookie);
        addToast('success', 'Refresh Successful', data.message || 'Cookie refreshed.');

        if (mode === 'detailed' && data.details) {
          setDetails(data.details);
        }
      } else {
        addToast('error', 'Refresh Failed', data.message || 'Invalid cookie or session expired.');
      }
    } catch (err) {
      addToast('error', 'Network Error', 'Could not connect to refresher server.');
    } finally {
      setLoading(false);
    }
  }, [inputCookie, logoutAll, mode, addToast]);

  return {
    inputCookie,
    setInputCookie,
    refreshedCookie,
    mode,
    setMode,
    logoutAll,
    setLogoutAll,
    loading,
    details,
    toasts,
    isCopied,
    addToast,
    dismissToast,
    clearInput,
    pasteCookie,
    copyCookie,
    refresh
  };
};
