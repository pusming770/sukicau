import React from 'react';
import { Sparkles, PersonStanding } from 'lucide-react';
import { AnimationAsset, LimitedItem } from '../types';

interface AssetsViewProps {
  animations?: AnimationAsset[];
  limitedItems?: LimitedItem[];
}

export const AssetsView: React.FC<AssetsViewProps> = ({ animations = [], limitedItems = [] }) => {
  return (
    <div className="mb-6">
      {/* Animation Packs */}
      <div className="flex items-center gap-2 text-[11px] font-semibold text-white/50 tracking-[0.08em] uppercase mb-3 px-1">
        <PersonStanding className="w-3.5 h-3.5 text-[#BF5AF2]" />
        <span>Animation Packs ({animations.length})</span>
      </div>

      {animations.length === 0 ? (
        <div className="text-center py-4 text-white/40 text-[12.5px] bg-white/[0.02] border border-white/[0.06] rounded-xl mb-5">
          No animations found.
        </div>
      ) : (
        <div className="grid grid-cols-3 sm:grid-cols-4 md:grid-cols-5 gap-2.5 mb-5">
          {animations.map((anim, idx) => (
            <div
              key={`${anim.id}_${idx}`}
              className="bg-white/[0.03] border border-white/[0.07] hover:border-white/15 hover:bg-white/[0.06] rounded-xl p-2 flex flex-col items-center text-center transition-all duration-200 group"
            >
              <img
                src={anim.thumbnail || 'https://via.placeholder.com/60?text=Pack'}
                alt={anim.name}
                className="w-14 h-14 rounded-lg object-cover bg-white/5 mb-1.5 shadow-sm group-hover:scale-105 transition-transform"
                loading="lazy"
              />
              <span
                className="text-[11px] font-medium text-white/70 line-clamp-2 leading-snug group-hover:text-white transition-colors"
                title={anim.name}
              >
                {anim.name}
              </span>
            </div>
          ))}
        </div>
      )}

      {/* Limited Items */}
      <div className="flex items-center gap-2 text-[11px] font-semibold text-white/50 tracking-[0.08em] uppercase mb-3 px-1">
        <Sparkles className="w-3.5 h-3.5 text-[#FF9F0A]" />
        <span>Limited Collectibles ({limitedItems.length})</span>
      </div>

      {limitedItems.length === 0 ? (
        <div className="text-center py-4 text-white/40 text-[12.5px] bg-white/[0.02] border border-white/[0.06] rounded-xl">
          No limited items found.
        </div>
      ) : (
        <div className="grid grid-cols-3 sm:grid-cols-4 md:grid-cols-5 gap-2.5">
          {limitedItems.map((item, idx) => (
            <div
              key={`${item.assetId}_${idx}`}
              className="bg-white/[0.03] border border-white/[0.07] hover:border-white/15 hover:bg-white/[0.06] rounded-xl p-2 flex flex-col items-center text-center transition-all duration-200 group"
            >
              <img
                src={item.thumbnail || 'https://via.placeholder.com/60'}
                alt={item.name}
                className="w-14 h-14 rounded-lg object-cover bg-white/5 mb-1.5 shadow-sm group-hover:scale-105 transition-transform"
                loading="lazy"
              />
              <span
                className="text-[11px] font-medium text-white/70 line-clamp-1 leading-snug group-hover:text-white transition-colors"
                title={item.name}
              >
                {item.name}
              </span>
              <span className="text-[11px] font-bold text-[#FFD60A] mt-0.5">
                {item.recentAveragePrice.toLocaleString()} R$
              </span>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};
