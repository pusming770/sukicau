import { RefreshRequest, RefreshResponse, AppError, StreamProgressCallback, RateLimitNotice } from '../types';

// API client for cookie refresh and live progress streaming
class RefresherApiService {
  private apiEndpoint = '/api/index.php';
  private fallbackEndpoint = '/index.php?action=refresh';

  public async refresh(
    request: RefreshRequest,
    onProgress?: StreamProgressCallback,
    signal?: AbortSignal
  ): Promise<RefreshResponse> {
    // Generous timeout to allow multiple auto-retry loops on rate limits
    const timeoutMs = request.detailed ? 90000 : 60000;
    const controller = new AbortController();

    // Link incoming signal to internal timeout controller
    const timeoutId = setTimeout(() => {
      controller.abort();
    }, timeoutMs);

    if (signal) {
      signal.addEventListener('abort', () => {
        controller.abort();
      });
    }

    try {
      const payload = {
        cookie: request.cookie,
        logout_all: request.logoutAll,
        detailed: request.detailed
      };

      let response: Response;
      try {
        response = await fetch(`${this.apiEndpoint}?stream=1`, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Accept': 'text/event-stream, application/json'
          },
          body: JSON.stringify(payload),
          signal: controller.signal
        });
      } catch (err: unknown) {
        // If /api/index.php?stream=1 is not reached, attempt fallback
        if (err instanceof DOMException && err.name === 'AbortError') {
          throw err;
        }

        const formData = new FormData();
        formData.append('cookie', request.cookie);
        formData.append('logout_all', request.logoutAll ? 'true' : 'false');
        formData.append('detailed', request.detailed ? 'true' : 'false');

        response = await fetch(this.fallbackEndpoint, {
          method: 'POST',
          body: formData,
          signal: controller.signal
        });
      }

      const contentType = response.headers.get('content-type') || '';

      // Handle real-time SSE Streaming
      if (contentType.includes('text/event-stream') && response.body) {
        const reader = response.body.getReader();
        const decoder = new TextDecoder();
        let buffer = '';
        let finalResponse: RefreshResponse | null = null;

        while (true) {
          const { done, value } = await reader.read();
          if (done) break;

          buffer += decoder.decode(value, { stream: true });
          const blocks = buffer.split('\n\n');
          buffer = blocks.pop() || '';

          for (const block of blocks) {
            const dataMatch = block.match(/^data:\s*(.+)$/m);
            if (dataMatch) {
              try {
                const event = JSON.parse(dataMatch[1]);
                if (event.type === 'ratelimit_wait') {
                  const notice: RateLimitNotice = {
                    step: event.step || 'auth',
                    attempt: event.attempt || 1,
                    waitSeconds: event.wait_seconds || 2,
                    message: event.message || 'Roblox rate limit hit. Waiting...'
                  };
                  if (onProgress) {
                    onProgress(notice, event.message);
                  }
                } else if (event.type === 'refreshed') {
                  if (onProgress) {
                    onProgress(null, event.message || 'Cookie berhasil diperbarui! Memuat detail...', event.cookie);
                  }
                } else if (event.type === 'status') {
                  if (onProgress) {
                    onProgress(null, event.message);
                  }
                } else if (event.type === 'completed') {
                  if (onProgress) {
                    onProgress(null);
                  }
                  finalResponse = {
                    success: true,
                    message: event.message || 'Cookie successfully refreshed.',
                    cookie: event.cookie,
                    details: event.details
                  };
                } else if (event.type === 'error') {
                  throw {
                    code: 'REFRESH_FAILED',
                    message: event.message || 'Refresh failed.',
                    status: 400
                  } as AppError;
                }
              } catch (e: any) {
                if (e && e.code === 'REFRESH_FAILED') {
                  throw e;
                }
              }
            }
          }
        }

        clearTimeout(timeoutId);

        if (finalResponse && finalResponse.success) {
          return finalResponse;
        }

        throw {
          code: 'REFRESH_FAILED',
          message: 'Refresh ended without obtaining a new cookie.',
          status: response.status
        } as AppError;
      }

      // Handle Standard JSON fallback
      clearTimeout(timeoutId);

      if (!contentType.includes('application/json')) {
        throw {
          code: 'INVALID_SERVER_RESPONSE',
          message: 'The server returned an unexpected response format.',
          status: response.status
        } as AppError;
      }

      const data = await response.json();

      if (!response.ok || !data.success) {
        throw {
          code: 'REFRESH_FAILED',
          message: data.message || 'Unable to refresh cookie.',
          status: response.status
        } as AppError;
      }

      return data as RefreshResponse;
    } catch (err: unknown) {
      clearTimeout(timeoutId);

      if (err instanceof DOMException && err.name === 'AbortError') {
        throw {
          code: 'REQUEST_TIMEOUT',
          message: 'Permintaan memakan waktu terlalu lama. Silakan periksa koneksi Anda.'
        } as AppError;
      }

      // Re-throw normalized AppError
      if (typeof err === 'object' && err !== null && 'message' in err) {
        throw err as AppError;
      }

      throw {
        code: 'NETWORK_ERROR',
        message: 'Gagal terhubung ke server refresher. Periksa koneksi Anda.'
      } as AppError;
    }
  }

  public async checkHealth(): Promise<boolean> {
    try {
      const res = await fetch(`${this.apiEndpoint}?health=1`, {
        method: 'GET',
        headers: { 'Accept': 'application/json' }
      });
      return res.ok;
    } catch {
      return false;
    }
  }
}

export const refresherApi = new RefresherApiService();
