import React from 'react';
import { Zap, PieChart } from 'lucide-react';

interface SegmentedControlProps {
  mode: 'basic' | 'detailed';
  onChange: (mode: 'basic' | 'detailed') => void;
  disabled?: boolean;
}

export const SegmentedControl: React.FC<SegmentedControlProps> = ({ mode, onChange, disabled }) => {
  return (
    <div className="flex bg-black/40 p-1 rounded-2xl border border-white/10 backdrop-blur-xl w-full max-w-[280px] mx-auto mb-6 shrink-0 relative">
      <button
        type="button"
        disabled={disabled}
        onClick={() => onChange('basic')}
        className={`flex-1 flex items-center justify-center gap-1.5 py-1.5 px-3 rounded-xl text-[13px] font-medium transition-all duration-200 outline-none ${
          mode === 'basic'
            ? 'bg-white/[0.14] text-white font-semibold shadow-[0_2px_8px_rgba(0,0,0,0.4),inset_0_0.5px_0.5px_rgba(255,255,255,0.3)]'
            : 'text-white/50 hover:text-white/80 hover:bg-white/[0.04]'
        }`}
      >
        <Zap className="w-3.5 h-3.5" />
        <span>Basic</span>
      </button>

      <button
        type="button"
        disabled={disabled}
        onClick={() => onChange('detailed')}
        className={`flex-1 flex items-center justify-center gap-1.5 py-1.5 px-3 rounded-xl text-[13px] font-medium transition-all duration-200 outline-none ${
          mode === 'detailed'
            ? 'bg-white/[0.14] text-white font-semibold shadow-[0_2px_8px_rgba(0,0,0,0.4),inset_0_0.5px_0.5px_rgba(255,255,255,0.3)]'
            : 'text-white/50 hover:text-white/80 hover:bg-white/[0.04]'
        }`}
      >
        <PieChart className="w-3.5 h-3.5" />
        <span>Detailed</span>
      </button>
    </div>
  );
};
