import React from 'react';

export interface BadgeProps extends React.HTMLAttributes<HTMLSpanElement> {
  variant?: 'neutral' | 'success' | 'warning' | 'danger' | 'premium' | 'info';
}

export const Badge: React.FC<BadgeProps> = ({
  children,
  variant = 'neutral',
  className = '',
  ...props
}) => {
  const variantStyles = {
    neutral: 'bg-white/[0.08] text-white/70 border-white/10',
    success: 'bg-[#30D158]/15 text-[#30D158] border-[#30D158]/30',
    warning: 'bg-[#FF9F0A]/15 text-[#FF9F0A] border-[#FF9F0A]/30',
    danger: 'bg-[#FF453A]/15 text-[#FF453A] border-[#FF453A]/30',
    premium: 'bg-[#FFD60A]/15 text-[#FFD60A] border-[#FFD60A]/30',
    info: 'bg-[#A855F7]/15 text-[#A855F7] border-[#A855F7]/30'
  }[variant];

  return (
    <span
      {...props}
      className={`inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-[11px] font-semibold tracking-wide uppercase border ${variantStyles} ${className}`}
    >
      {children}
    </span>
  );
};
