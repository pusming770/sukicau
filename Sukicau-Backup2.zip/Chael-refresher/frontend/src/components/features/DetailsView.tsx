import React, { useState } from 'react';
import { AccountDetails } from '../../types';
import { AccountSummary } from './AccountSummary';
import { EconomyOverview } from './EconomyOverview';
import { AssetsGrid } from './AssetsGrid';
import { PurchasesSection } from './PurchasesSection';
import { TransactionsSection } from './TransactionsSection';
import { UserCheck, Sparkles, Gamepad2, Receipt, LayoutGrid, Eye } from 'lucide-react';

interface DetailsViewProps {
  details: AccountDetails | null;
}

type TabType = 'overview' | 'assets' | 'purchases' | 'transactions' | 'all';

export const DetailsView: React.FC<DetailsViewProps> = ({ details }) => {
  const [activeTab, setActiveTab] = useState<TabType>('overview');

  if (!details) return null;

  const totalAssetsCount =
    (details.limitedItems?.length || 0) +
    (details.sfxItems?.length || 0) +
    (details.animations?.length || 0);

  const transactionsCount = details.transactions?.length || 0;

  return (
    <div className="w-full mt-7 pt-6 border-t border-white/10 animate-appear">
      {/* Header Badge */}
      <div className="flex items-center justify-between mb-4 px-1 flex-wrap gap-2">
        <div className="flex items-center gap-2">
          <div className="w-7 h-7 rounded-lg bg-[#A855F7]/20 flex items-center justify-center text-[#A855F7]">
            <UserCheck className="w-4 h-4" />
          </div>
          <h3 className="text-[16px] font-semibold text-white tracking-tight">
            Detail Akun & Aset
          </h3>
        </div>

        {/* View All Toggle Button */}
        <button
          type="button"
          onClick={() => setActiveTab(activeTab === 'all' ? 'overview' : 'all')}
          className={`flex items-center gap-1.5 px-2.5 py-1 rounded-full text-[11.5px] font-medium transition-all ${
            activeTab === 'all'
              ? 'bg-white/20 text-white shadow-sm border border-white/20'
              : 'bg-white/[0.04] text-white/50 hover:text-white border border-white/5'
          }`}
        >
          <Eye className="w-3 h-3" />
          <span>{activeTab === 'all' ? 'Mode Tab' : 'Tampilkan Semua'}</span>
        </button>
      </div>

      {/* Segmented Navigation Tabs (Clean & Organized - Anti Tumpuk-Menumpuk) */}
      {activeTab !== 'all' && (
        <div className="w-full p-1 rounded-2xl bg-white/[0.04] border border-white/10 mb-6 flex items-center overflow-x-auto no-scrollbar gap-1">
          {/* Tab 1: Overview */}
          <button
            type="button"
            onClick={() => setActiveTab('overview')}
            className={`flex-1 min-w-[90px] py-2 px-3 rounded-xl flex items-center justify-center gap-1.5 text-[12.5px] font-medium transition-all outline-none cursor-pointer ${
              activeTab === 'overview'
                ? 'bg-[#A855F7] text-white shadow-md'
                : 'text-white/60 hover:text-white hover:bg-white/[0.03]'
            }`}
          >
            <LayoutGrid className="w-3.5 h-3.5 shrink-0" />
            <span className="truncate">Ringkasan</span>
          </button>

          {/* Tab 2: Assets & SFX */}
          <button
            type="button"
            onClick={() => setActiveTab('assets')}
            className={`flex-1 min-w-[110px] py-2 px-3 rounded-xl flex items-center justify-center gap-1.5 text-[12.5px] font-medium transition-all outline-none cursor-pointer ${
              activeTab === 'assets'
                ? 'bg-[#A855F7] text-white shadow-md'
                : 'text-white/60 hover:text-white hover:bg-white/[0.03]'
            }`}
          >
            <Sparkles className="w-3.5 h-3.5 shrink-0" />
            <span className="truncate">Aset & SFX</span>
            {totalAssetsCount > 0 && (
              <span
                className={`text-[10px] px-1.5 py-0.2 rounded-full font-mono font-bold ${
                  activeTab === 'assets'
                    ? 'bg-white/25 text-white'
                    : 'bg-white/10 text-white/60'
                }`}
              >
                {totalAssetsCount}
              </span>
            )}
          </button>

          {/* Tab 3: Purchases */}
          <button
            type="button"
            onClick={() => setActiveTab('purchases')}
            className={`flex-1 min-w-[95px] py-2 px-3 rounded-xl flex items-center justify-center gap-1.5 text-[12.5px] font-medium transition-all outline-none cursor-pointer ${
              activeTab === 'purchases'
                ? 'bg-[#A855F7] text-white shadow-md'
                : 'text-white/60 hover:text-white hover:bg-white/[0.03]'
            }`}
          >
            <Gamepad2 className="w-3.5 h-3.5 shrink-0" />
            <span className="truncate">Purchases</span>
          </button>

          {/* Tab 4: Transactions */}
          <button
            type="button"
            onClick={() => setActiveTab('transactions')}
            className={`flex-1 min-w-[100px] py-2 px-3 rounded-xl flex items-center justify-center gap-1.5 text-[12.5px] font-medium transition-all outline-none cursor-pointer ${
              activeTab === 'transactions'
                ? 'bg-[#A855F7] text-white shadow-md'
                : 'text-white/60 hover:text-white hover:bg-white/[0.03]'
            }`}
          >
            <Receipt className="w-3.5 h-3.5 shrink-0" />
            <span className="truncate">Transaksi</span>
            {transactionsCount > 0 && (
              <span
                className={`text-[10px] px-1.5 py-0.2 rounded-full font-mono font-bold ${
                  activeTab === 'transactions'
                    ? 'bg-white/25 text-white'
                    : 'bg-white/10 text-white/60'
                }`}
              >
                {transactionsCount}
              </span>
            )}
          </button>
        </div>
      )}

      {/* Tab Content Display */}
      {activeTab === 'all' ? (
        /* View All Mode */
        <div className="flex flex-col gap-6">
          <AccountSummary details={details} />
          <EconomyOverview details={details} />
          <AssetsGrid
            animations={details.animations}
            limitedItems={details.limitedItems}
            sfxItems={details.sfxItems}
          />
          <PurchasesSection transactions={details.transactions} />
          <TransactionsSection transactions={details.transactions} />
        </div>
      ) : activeTab === 'overview' ? (
        /* Overview: Identity + Economy Bento */
        <div className="flex flex-col gap-4 animate-appear">
          <AccountSummary details={details} />
          <EconomyOverview details={details} />
        </div>
      ) : activeTab === 'assets' ? (
        /* Assets & SFX Items */
        <div className="animate-appear">
          <AssetsGrid
            animations={details.animations}
            limitedItems={details.limitedItems}
            sfxItems={details.sfxItems}
          />
        </div>
      ) : activeTab === 'purchases' ? (
        /* Game Passes & Catalog Purchases */
        <div className="animate-appear">
          <PurchasesSection transactions={details.transactions} />
        </div>
      ) : (
        /* Transaction History */
        <div className="animate-appear">
          <TransactionsSection transactions={details.transactions} />
        </div>
      )}
    </div>
  );
};
