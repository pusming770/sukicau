import React, { useState } from 'react';
import { Transaction } from '../../types';
import { ShoppingBag, ChevronDown, ChevronUp, Gamepad2, ArrowUpRight, ArrowDownRight, Ticket } from 'lucide-react';

interface PurchasesSectionProps {
  transactions?: Transaction[];
}

interface GameGroup {
  key: string;
  name: string;
  icon?: string;
  items: Transaction[];
}

interface StackedItem {
  id: string | number;
  name: string;
  thumbnail?: string;
  unitPrice: number;
  totalPrice: number;
  count: number;
  itemType?: string;
}

const GameIconImage: React.FC<{ src?: string; fallbackSrc?: string; name: string }> = ({ src, fallbackSrc, name }) => {
  const [hasError, setHasError] = useState(false);
  const targetSrc = (!hasError && src) ? src : (!hasError && fallbackSrc ? fallbackSrc : null);

  if (!targetSrc || hasError) {
    return <Gamepad2 className="w-6 h-6 text-[#A855F7]" />;
  }

  return (
    <img
      src={targetSrc}
      alt={name}
      loading="lazy"
      onError={() => setHasError(true)}
      className="w-full h-full object-cover"
    />
  );
};

export const PurchasesSection: React.FC<PurchasesSectionProps> = ({ transactions = [] }) => {
  const [expandedGames, setExpandedGames] = useState<Record<string, boolean>>({});

  const formatNumber = (num: number) => {
    return new Intl.NumberFormat().format(num);
  };

  const toggleGame = (key: string) => {
    setExpandedGames((prev) => ({
      ...prev,
      [key]: !prev[key]
    }));
  };

  const purchases = transactions.filter((tx) => tx.type === 'Purchase' || !tx.income);
  const sales = transactions.filter((tx) => tx.type === 'Sale' || tx.income);

  // Group purchases by game/universe
  const gameGroups: GameGroup[] = [];
  const nonGamePurchases: Transaction[] = [];
  const groupMap = new Map<string, GameGroup>();

  purchases.forEach((tx) => {
    const cleanType = (tx.itemType || '').toLowerCase().replace(/[\s_-]/g, '');
    const isGameType = cleanType === 'gamepass' || cleanType === 'developerproduct' || cleanType === 'badge';
    const isGame = !!(tx.universeId || tx.placeId || (tx.gameName && tx.gameName.trim() !== '') || tx.gameIcon || isGameType);

    if (isGame) {
      const key = tx.universeId
        ? `u_${tx.universeId}`
        : tx.placeId
        ? `p_${tx.placeId}`
        : tx.gameName && tx.gameName.trim() !== ''
        ? `g_${encodeURIComponent(tx.gameName.trim())}`
        : tx.sellerId
        ? `s_${tx.sellerId}`
        : 'in_game_experience';

      const defaultName = tx.gameName || (isGameType ? 'In-Game Experience' : 'Game Experience');

      if (!groupMap.has(key)) {
        const group: GameGroup = {
          key,
          name: defaultName,
          icon: tx.gameIcon,
          items: []
        };
        groupMap.set(key, group);
        gameGroups.push(group);
      }

      const existing = groupMap.get(key)!;
      if (tx.gameName && (!existing.name || existing.name === 'Game Experience' || existing.name === 'In-Game Experience')) {
        existing.name = tx.gameName;
      }
      if (tx.gameIcon && !existing.icon) {
        existing.icon = tx.gameIcon;
      }
      existing.items.push(tx);
    } else {
      nonGamePurchases.push(tx);
    }
  });

  const allExpanded = gameGroups.length > 0 && gameGroups.every((g) => !!expandedGames[g.key]);
  const toggleAll = () => {
    if (allExpanded) {
      setExpandedGames({});
    } else {
      const next: Record<string, boolean> = {};
      gameGroups.forEach((g) => {
        next[g.key] = true;
      });
      setExpandedGames(next);
    }
  };

  // Helper to stack identical items
  const stackItems = (items: Transaction[]): StackedItem[] => {
    const map = new Map<string, StackedItem>();
    items.forEach((item) => {
      const itemName = (item.name || item.detail || item.type || 'Item').trim();
      const unitPrice = Math.abs(item.amount);
      const stackKey = item.assetId
        ? `id_${item.assetId}_${unitPrice}`
        : `name_${itemName.toLowerCase()}_${unitPrice}`;

      if (map.has(stackKey)) {
        const existing = map.get(stackKey)!;
        existing.count += 1;
        existing.totalPrice += unitPrice;
        if (!existing.thumbnail && (item.thumbnail || item.creatorAvatar)) {
          existing.thumbnail = item.thumbnail || item.creatorAvatar;
        }
      } else {
        map.set(stackKey, {
          id: item.assetId || stackKey,
          name: itemName,
          thumbnail: item.thumbnail || item.creatorAvatar,
          unitPrice,
          totalPrice: unitPrice,
          count: 1,
          itemType: item.itemType
        });
      }
    });
    return Array.from(map.values());
  };

  return (
    <div className="w-full flex flex-col gap-4 mb-6">
      {/* Game Experience Purchases */}
      <div>
        <div className="flex items-center justify-between mb-2.5 px-1">
          <div className="flex items-center gap-1.5 text-[11px] font-semibold text-white/50 uppercase tracking-wider">
            <Gamepad2 className="w-3.5 h-3.5 text-[#A855F7]" />
            <span>Game Experience Purchases</span>
            {gameGroups.length > 0 && (
              <span className="text-white/30 text-[10.5px]">({gameGroups.length} Games)</span>
            )}
          </div>

          {gameGroups.length > 1 && (
            <button
              type="button"
              onClick={toggleAll}
              className="text-[11px] font-medium text-[#A855F7] hover:underline cursor-pointer"
            >
              {allExpanded ? 'Collapse All' : 'Expand All'}
            </button>
          )}
        </div>

        {gameGroups.length > 0 ? (
          <div className="flex flex-col gap-2.5">
            {gameGroups.map((game) => {
              const isExpanded = !!expandedGames[game.key];
              const totalSpent = game.items.reduce((sum, item) => sum + Math.abs(item.amount), 0);
              const stackedPasses = stackItems(game.items);

              return (
                <div
                  key={game.key}
                  className="rounded-2xl bg-white/[0.03] border border-white/10 overflow-hidden transition-all duration-200 hover:border-white/20"
                >
                  {/* Game Header (Photo, Name, Total Spent on that game) */}
                  <button
                    type="button"
                    onClick={() => toggleGame(game.key)}
                    className="w-full flex items-center justify-between p-3.5 text-left hover:bg-white/[0.04] transition-colors outline-none cursor-pointer gap-3"
                  >
                    {/* Left: (game photo) + (game name) */}
                    <div className="flex items-center gap-3 min-w-0 flex-1">
                      {/* (game photo) */}
                      <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-white/10 to-white/5 overflow-hidden shrink-0 flex items-center justify-center border border-white/10 shadow-sm">
                        <GameIconImage
                          src={game.icon}
                          fallbackSrc={game.items.find((i) => !!i.thumbnail || !!i.gameIcon)?.thumbnail}
                          name={game.name}
                        />
                      </div>

                      {/* (game name) */}
                      <div className="flex flex-col min-w-0">
                        <span className="text-[14px] font-semibold text-white truncate" title={game.name}>
                          {game.name}
                        </span>
                        <span className="text-[11.5px] text-white/50 flex items-center gap-1.5 mt-0.5">
                          <span>{game.items.length} {game.items.length > 1 ? 'items' : 'item'} purchased</span>
                          {stackedPasses.length < game.items.length && (
                            <span className="text-[#A855F7]/80">({stackedPasses.length} unique)</span>
                          )}
                        </span>
                      </div>
                    </div>

                    {/* Right: (total spent on that game) + Chevron */}
                    <div className="flex items-center gap-3 shrink-0">
                      <div className="flex flex-col items-end">
                        <span className="text-[#FFD60A] font-bold text-[14px] tabular-nums drop-shadow-[0_0_8px_rgba(255,214,10,0.25)]">
                          -{formatNumber(totalSpent)} R$
                        </span>
                        <span className="text-white/40 text-[10.5px]">Total Spent</span>
                      </div>

                      <div className="w-7 h-7 rounded-full bg-white/[0.06] flex items-center justify-center text-white/60 transition-transform duration-200">
                        {isExpanded ? (
                          <ChevronUp className="w-4 h-4 text-white" />
                        ) : (
                          <ChevronDown className="w-4 h-4" />
                        )}
                      </div>
                    </div>
                  </button>

                  {/* Expanded Content: list of (foto gamepass) (nama gamepass) (harga gamepass) with ?x stack */}
                  {isExpanded && (
                    <div className="px-3.5 pb-3.5 pt-1 border-t border-white/[0.06] flex flex-col gap-2 animate-appear bg-black/20">
                      <div className="text-[11px] font-medium text-white/40 px-1 pt-1 uppercase tracking-wider flex items-center justify-between">
                        <span>Purchased Passes & Items</span>
                        <span>Price</span>
                      </div>

                      {stackedPasses.map((item, idx) => (
                        <div
                          key={idx}
                          className="flex items-center justify-between p-2.5 rounded-xl bg-white/[0.025] hover:bg-white/[0.06] border border-white/[0.05] transition-colors gap-3"
                        >
                          {/* Left: (foto gamepass) + (nama gamepass) + stack count ?x */}
                          <div className="flex items-center gap-3 min-w-0 flex-1">
                            {/* (foto gamepass) */}
                            <div className="w-10 h-10 rounded-lg bg-black/40 overflow-hidden shrink-0 flex items-center justify-center border border-white/10 shadow-sm">
                              {item.thumbnail ? (
                                <img
                                  src={item.thumbnail}
                                  alt={item.name}
                                  loading="lazy"
                                  className="w-full h-full object-cover"
                                />
                              ) : (
                                <Ticket className="w-5 h-5 text-white/40" />
                              )}
                            </div>

                            {/* (nama gamepass) + stack count ?x */}
                            <div className="flex items-center gap-2 min-w-0 flex-wrap">
                              <span className="text-white/90 font-medium text-[13px] truncate" title={item.name}>
                                {item.name}
                              </span>
                              {item.count > 1 && (
                                <span className="px-1.5 py-0.5 rounded-md bg-[#A855F7]/20 text-[#A855F7] border border-[#A855F7]/30 font-mono text-[11px] font-bold shrink-0 shadow-sm">
                                  {item.count}x
                                </span>
                              )}
                            </div>
                          </div>

                          {/* Right: (harga gamepass) */}
                          <div className="flex flex-col items-end shrink-0">
                            <span className="text-[#FF453A] font-semibold text-[13px] tabular-nums">
                              -{formatNumber(item.totalPrice)} R$
                            </span>
                            {item.count > 1 && (
                              <span className="text-white/40 text-[10.5px] tabular-nums">
                                @{formatNumber(item.unitPrice)} R$
                              </span>
                            )}
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        ) : (
          <div className="rounded-xl bg-white/[0.02] border border-white/5 p-4 text-center text-white/40 text-[12px]">
            No in-game purchases detected.
          </div>
        )}
      </div>

      {/* Non-Game Purchases (Catalog & Other) */}
      {nonGamePurchases.length > 0 && (
        <div>
          <div className="flex items-center gap-1.5 text-[11px] font-semibold text-white/50 uppercase tracking-wider mb-2 ml-1">
            <ArrowDownRight className="w-3.5 h-3.5 text-[#FF453A]" />
            <span>Catalog & Other Purchases ({nonGamePurchases.length})</span>
          </div>

          <div className="rounded-2xl bg-white/[0.03] border border-white/10 p-2.5 flex flex-col gap-1.5 max-h-72 overflow-y-auto">
            {stackItems(nonGamePurchases).map((item, idx) => (
              <div
                key={idx}
                className="flex items-center justify-between p-2 rounded-xl hover:bg-white/[0.05] transition-colors text-[12.5px] gap-2.5"
              >
                <div className="flex items-center gap-2.5 min-w-0 flex-1">
                  <div className="w-9 h-9 rounded-lg bg-black/40 overflow-hidden shrink-0 flex items-center justify-center border border-white/10">
                    {item.thumbnail ? (
                      <img src={item.thumbnail} alt={item.name} loading="lazy" className="w-full h-full object-cover" />
                    ) : (
                      <ShoppingBag className="w-4 h-4 text-white/30" />
                    )}
                  </div>
                  <div className="flex items-center gap-1.5 min-w-0 flex-wrap">
                    <span className="text-white/80 truncate font-medium max-w-[200px] sm:max-w-sm" title={item.name}>
                      {item.name}
                    </span>
                    {item.count > 1 && (
                      <span className="px-1.5 py-0.5 rounded-md bg-white/10 text-white/70 font-mono text-[10.5px] font-semibold shrink-0">
                        {item.count}x
                      </span>
                    )}
                  </div>
                </div>

                <div className="flex flex-col items-end shrink-0">
                  <span className="text-[#FF453A] font-semibold tabular-nums">
                    -{formatNumber(item.totalPrice)} R$
                  </span>
                  {item.count > 1 && (
                    <span className="text-white/40 text-[10px] tabular-nums">
                      @{formatNumber(item.unitPrice)} R$
                    </span>
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Sales History */}
      {sales.length > 0 && (
        <div>
          <div className="flex items-center gap-1.5 text-[11px] font-semibold text-white/50 uppercase tracking-wider mb-2 ml-1">
            <ArrowUpRight className="w-3.5 h-3.5 text-[#30D158]" />
            <span>Sales History ({sales.length})</span>
          </div>

          <div className="rounded-2xl bg-white/[0.03] border border-white/10 p-2.5 flex flex-col gap-1.5 max-h-72 overflow-y-auto">
            {stackItems(sales).map((sale, idx) => (
              <div
                key={idx}
                className="flex items-center justify-between p-2 rounded-xl hover:bg-white/[0.05] transition-colors text-[12.5px] gap-2.5"
              >
                <div className="flex items-center gap-2.5 min-w-0 flex-1">
                  <div className="w-9 h-9 rounded-lg bg-black/40 overflow-hidden shrink-0 flex items-center justify-center border border-white/10">
                    {sale.thumbnail ? (
                      <img src={sale.thumbnail} alt={sale.name} loading="lazy" className="w-full h-full object-cover" />
                    ) : (
                      <ArrowUpRight className="w-4 h-4 text-[#30D158]" />
                    )}
                  </div>
                  <div className="flex items-center gap-1.5 min-w-0 flex-wrap">
                    <span className="text-white/80 truncate font-medium max-w-[200px] sm:max-w-sm" title={sale.name}>
                      {sale.name}
                    </span>
                    {sale.count > 1 && (
                      <span className="px-1.5 py-0.5 rounded-md bg-[#30D158]/20 text-[#30D158] font-mono text-[10.5px] font-semibold shrink-0">
                        {sale.count}x
                      </span>
                    )}
                  </div>
                </div>

                <div className="flex flex-col items-end shrink-0">
                  <span className="text-[#30D158] font-semibold tabular-nums">
                    +{formatNumber(sale.totalPrice)} R$
                  </span>
                  {sale.count > 1 && (
                    <span className="text-white/40 text-[10px] tabular-nums">
                      @{formatNumber(sale.unitPrice)} R$
                    </span>
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};
