<?php
declare(strict_types=1);

namespace Langgor\Refresher;

class ProxyManager {
    private static array $proxies = [];
    private static bool $initialized = false;
    private static int $roundRobinIndex = 0;
    private static array $tempBlocked = [];
    private static string $source = 'none';

    public static function init(bool $forceReload = false): void {
        if (self::$initialized && !$forceReload) {
            return;
        }

        self::$proxies = [];
        self::$initialized = true;

        // 1. Single Rotating Proxy URL from .env (e.g. PROXY_URL=http://user:pass@gate.webshare.io:80)
        $proxyUrl = trim((string)Config::get('PROXY_URL', ''));
        if (!empty($proxyUrl)) {
            $parsed = self::parseProxyString($proxyUrl);
            if ($parsed !== null) {
                self::$proxies[] = $parsed;
                self::$source = 'PROXY_URL';
            }
        }

        // 2. Comma-separated list from .env (e.g. PROXY_LIST=http://...,http://...)
        $proxyList = trim((string)Config::get('PROXY_LIST', ''));
        if (!empty($proxyList)) {
            $items = explode(',', $proxyList);
            foreach ($items as $item) {
                $parsed = self::parseProxyString(trim($item));
                if ($parsed !== null) {
                    self::$proxies[] = $parsed;
                }
            }
            if (!empty(self::$proxies)) {
                self::$source = 'PROXY_LIST';
            }
        }

        // 3. Proxy list file (e.g. custom file, proxies.txt in root or server/proxies.txt)
        $customFile = (string)Config::get('PROXIES_FILE', '');
        $possibleFiles = array_filter([
            $customFile,
            __DIR__ . '/../proxies.txt',
            __DIR__ . '/proxies.txt'
        ]);

        foreach ($possibleFiles as $file) {
            if (file_exists($file)) {
                $lines = @file($file, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
                if (is_array($lines)) {
                    $fileCount = 0;
                    foreach ($lines as $line) {
                        $parsed = self::parseProxyString(trim($line));
                        if ($parsed !== null) {
                            self::$proxies[] = $parsed;
                            $fileCount++;
                        }
                    }
                    if ($fileCount > 0) {
                        self::$source = basename($file);
                        break;
                    }
                }
            }
        }
    }

    public static function isEnabled(): bool {
        self::init();
        $configEnabled = Config::get('PROXY_ENABLED', null);
        if ($configEnabled !== null) {
            return $configEnabled === 'true' || $configEnabled === true || $configEnabled === '1' || $configEnabled === 1;
        }
        // Auto-enable if proxies are found in pool
        return !empty(self::$proxies);
    }

    public static function getProxyCount(): int {
        self::init();
        return count(self::$proxies);
    }

    public static function getSource(): string {
        self::init();
        return self::$source;
    }

    public static function parseProxyString(string $line): ?array {
        $line = trim($line);
        if ($line === '' || str_starts_with($line, '#')) {
            return null;
        }

        $scheme = 'http';
        $type = CURLPROXY_HTTP;
        $user = null;
        $pass = null;
        $host = '';
        $port = 80;

        // Check if protocol scheme prefix exists (e.g. socks5://, http://, https://)
        if (preg_match('/^([a-z0-9]+):\/\/(.+)$/i', $line, $pm)) {
            $scheme = strtolower($pm[1]);
            $rest = $pm[2];

            if (str_starts_with($scheme, 'socks5')) {
                $type = defined('CURLPROXY_SOCKS5_HOSTNAME') ? CURLPROXY_SOCKS5_HOSTNAME : CURLPROXY_SOCKS5;
            } elseif (str_starts_with($scheme, 'socks4')) {
                $type = defined('CURLPROXY_SOCKS4A') ? CURLPROXY_SOCKS4A : CURLPROXY_SOCKS4;
            } elseif ($scheme === 'https') {
                $type = defined('CURLPROXY_HTTPS') ? CURLPROXY_HTTPS : CURLPROXY_HTTP;
            } else {
                $type = CURLPROXY_HTTP;
            }

            $parsed = parse_url('http://' . $rest);
            if (!empty($parsed['host'])) {
                $host = $parsed['host'];
                $port = (int)($parsed['port'] ?? ($scheme === 'https' ? 443 : 80));
                $user = !empty($parsed['user']) ? urldecode($parsed['user']) : null;
                $pass = !empty($parsed['pass']) ? urldecode($parsed['pass']) : null;
            }
        } else {
            // Formats: user:pass@ip:port OR ip:port:user:pass OR ip:port
            if (str_contains($line, '@')) {
                [$cred, $hp] = explode('@', $line, 2);
                if (str_contains($cred, ':')) {
                    [$user, $pass] = explode(':', $cred, 2);
                } else {
                    $user = $cred;
                }
                if (str_contains($hp, ':')) {
                    [$host, $portStr] = explode(':', $hp, 2);
                    $port = (int)$portStr;
                } else {
                    $host = $hp;
                }
            } else {
                $parts = explode(':', $line);
                if (count($parts) === 4) {
                    // ip:port:user:pass
                    $host = $parts[0];
                    $port = (int)$parts[1];
                    $user = $parts[2];
                    $pass = $parts[3];
                } elseif (count($parts) === 2) {
                    // ip:port
                    $host = $parts[0];
                    $port = (int)$parts[1];
                } elseif (count($parts) === 3) {
                    $host = $parts[0];
                    $port = (int)$parts[1];
                    $user = $parts[2];
                }
            }
        }

        if (empty($host) || $port <= 0) {
            return null;
        }

        return [
            'raw' => $line,
            'scheme' => $scheme,
            'type' => $type,
            'host' => $host,
            'port' => $port,
            'user' => $user,
            'pass' => $pass
        ];
    }

    private static function loadCooldowns(): void {
        $file = sys_get_temp_dir() . '/roblox_proxy_cooldown.json';
        if (file_exists($file)) {
            $raw = @file_get_contents($file);
            if ($raw) {
                $data = json_decode($raw, true);
                if (is_array($data)) {
                    $now = time();
                    self::$tempBlocked = [];
                    foreach ($data as $k => $exp) {
                        if ($now < (int)$exp) {
                            self::$tempBlocked[$k] = (int)$exp;
                        }
                    }
                }
            }
        }
    }

    private static function saveCooldowns(): void {
        $file = sys_get_temp_dir() . '/roblox_proxy_cooldown.json';
        $now = time();
        $cleaned = [];
        foreach (self::$tempBlocked as $k => $exp) {
            if ($now < $exp) {
                $cleaned[$k] = $exp;
            }
        }
        self::$tempBlocked = $cleaned;

        // Atomic file write using temp file and rename to ensure cross-process safety
        $tmpFile = $file . '.' . getmypid() . '.' . bin2hex(random_bytes(4)) . '.tmp';
        if (@file_put_contents($tmpFile, json_encode($cleaned, JSON_UNESCAPED_SLASHES), LOCK_EX) !== false) {
            @rename($tmpFile, $file);
        }
    }

    public static function cleanupCooldowns(): void {
        self::loadCooldowns();
        self::saveCooldowns();
    }

    /**
     * Get all currently available proxies (excluding dead or active cooldown ones).
     * Automatically restores any proxy whose cooldown has expired.
     */
    public static function getAvailableProxies(?array $exclude = null): array {
        if (!self::isEnabled() || empty(self::$proxies)) {
            return [];
        }

        self::loadCooldowns();
        $now = time();
        $hasExpired = false;
        foreach (self::$tempBlocked as $key => $expiresAt) {
            if ($now >= $expiresAt) {
                unset(self::$tempBlocked[$key]);
                $hasExpired = true;
            }
        }
        if ($hasExpired) {
            self::saveCooldowns();
        }

        $available = [];
        foreach (self::$proxies as $p) {
            $key = $p['host'] . ':' . $p['port'];
            if (isset(self::$tempBlocked[$key])) {
                continue;
            }
            if ($exclude !== null && ($exclude['host'] ?? '') === $p['host'] && ($exclude['port'] ?? 0) === $p['port']) {
                continue;
            }
            $available[] = $p;
        }

        return $available;
    }

    public static function getFastestProxy(?array $exclude = null): ?array {
        return self::getProxy('fastest', $exclude);
    }

    public static function getProxy(?string $strategy = null, ?array $exclude = null): ?array {
        $available = self::getAvailableProxies($exclude);
        if (empty($available)) {
            // Pool is exhausted (all proxies dead or in cooldown) - return null to trigger direct fallback
            return null;
        }

        $rotation = $strategy ?: (string)Config::get('PROXY_ROTATION', 'fastest_first');

        // Explicit fastest: return the lowest-latency alive proxy
        if ($rotation === 'fastest') {
            return $available[0] ?? null;
        }

        // Fastest-first rotation: cycle within the top 15 fastest available proxies
        if ($rotation === 'fastest_first' || $rotation === 'priority') {
            $fastPool = array_slice($available, 0, min(15, count($available)));
            $idx = self::$roundRobinIndex % count($fastPool);
            self::$roundRobinIndex++;
            return $fastPool[$idx];
        }

        if ($rotation === 'round_robin') {
            $idx = self::$roundRobinIndex % count($available);
            self::$roundRobinIndex++;
            return $available[$idx];
        }

        // Random rotation: pick randomly within top 20 fastest proxies to avoid high-latency long tail
        $topPool = array_slice($available, 0, min(20, count($available)));
        $randIdx = array_rand($topPool);
        return $topPool[$randIdx];
    }

    /**
     * Multitasking proxy allocator: Assign a dedicated, distinct, non-overlapping proxy
     * to each task key so concurrent requests hit Roblox from different IP addresses.
     *
     * @param array<string|int> $taskKeys List of endpoint task keys (e.g. ['email', 'currency', ...])
     * @param array<string|int, array|null> $existingOverrides Existing overrides (key => proxy or null)
     * @return array<string|int, array|null> Map of task key to assigned proxy (or null for direct connection)
     */
    public static function getDistinctProxiesForTasks(array $taskKeys, array $existingOverrides = []): array {
        $results = [];
        if (empty($taskKeys)) {
            return $results;
        }

        $available = self::getAvailableProxies();
        $poolCount = count($available);

        // If proxy system is disabled or all proxies in pool are exhausted, fallback all tasks to direct
        if (!self::isEnabled() || $poolCount === 0) {
            foreach ($taskKeys as $key) {
                $results[$key] = array_key_exists($key, $existingOverrides) ? $existingOverrides[$key] : null;
            }
            return $results;
        }

        // Limit active multitasking candidate pool to Top-Tier fastest verified proxies (e.g. top 30)
        // This completely prevents selecting tail proxies with 2.0s - 4.0s latency!
        $windowSize = (int)Config::get('PROXY_FAST_WINDOW', 30);
        $fastPool = array_slice($available, 0, min($windowSize, $poolCount));
        $fastCount = count($fastPool);

        $baseOffset = self::$roundRobinIndex;
        $assignedCount = 0;

        foreach ($taskKeys as $key) {
            // Check if caller provided explicit override (e.g. null for CDN or pinned proxy)
            if (array_key_exists($key, $existingOverrides)) {
                $results[$key] = $existingOverrides[$key];
                continue;
            }

            // Assign distinct proxy from the top-tier fast pool
            $pIdx = ($baseOffset + $assignedCount) % $fastCount;
            $results[$key] = $fastPool[$pIdx];
            $assignedCount++;
        }

        // Advance roundRobinIndex within the fast pool window
        self::$roundRobinIndex = (self::$roundRobinIndex + max(1, $assignedCount)) % $fastCount;

        return $results;
    }

    public static function applyProxy(&$ch, ?array $proxy = null): ?array {
        if (!self::isEnabled()) {
            return null;
        }

        // If caller explicitly passed 2nd argument (e.g. applyProxy($ch, null)), respect caller intent:
        // null means direct connection without proxy.
        // If caller called applyProxy($ch) with 1 argument, auto-pick proxy from pool.
        $chosen = (func_num_args() >= 2) ? $proxy : self::getProxy();
        if ($chosen === null) {
            return null;
        }

        curl_setopt($ch, CURLOPT_PROXY, $chosen['host']);
        curl_setopt($ch, CURLOPT_PROXYPORT, $chosen['port']);
        curl_setopt($ch, CURLOPT_PROXYTYPE, $chosen['type']);

        if (!empty($chosen['user'])) {
            $userPwd = $chosen['user'] . ':' . ($chosen['pass'] ?? '');
            curl_setopt($ch, CURLOPT_PROXYUSERPWD, $userPwd);
            curl_setopt($ch, CURLOPT_PROXYAUTH, CURLAUTH_BASIC);
        }

        return $chosen;
    }

    public static function markRateLimited(?array $proxy, int $cooldownSeconds = 60): void {
        if ($proxy === null || empty($proxy['host'])) {
            return;
        }
        self::loadCooldowns();
        $key = $proxy['host'] . ':' . ($proxy['port'] ?? 80);
        self::$tempBlocked[$key] = time() + max(1, $cooldownSeconds);
        self::saveCooldowns();
    }

    public static function getStatus(): array {
        self::init();
        self::loadCooldowns();
        $now = time();
        $count = count(self::$proxies);
        $enabled = self::isEnabled();
        $sample = null;
        if ($count > 0) {
            $first = self::$proxies[0];
            $sample = $first['scheme'] . '://' . ($first['user'] ? '***:***@' : '') . $first['host'] . ':' . $first['port'];
        }

        $cooldownList = [];
        $nextRestore = null;
        foreach (self::$tempBlocked as $k => $exp) {
            if ($exp > $now) {
                $remaining = $exp - $now;
                $cooldownList[$k] = $remaining;
                if ($nextRestore === null || $exp < $nextRestore) {
                    $nextRestore = $exp;
                }
            }
        }

        $cacheFile = __DIR__ . '/proxy_cache.json';
        $cacheInfo = null;
        if (file_exists($cacheFile)) {
            $raw = @file_get_contents($cacheFile);
            if ($raw) {
                $cacheInfo = json_decode($raw, true);
            }
        }

        return [
            'enabled' => $enabled,
            'total_proxies' => $count,
            'source' => self::$source,
            'active_pool' => max(0, $count - count($cooldownList)),
            'rate_limited_count' => count($cooldownList),
            'in_cooldown' => $cooldownList,
            'next_restore_seconds' => $nextRestore ? max(0, $nextRestore - $now) : null,
            'sample' => $sample,
            'checker_stats' => $cacheInfo ? [
                'last_checked' => $cacheInfo['last_checked'] ?? null,
                'next_check' => $cacheInfo['next_check'] ?? null,
                'total_scraped' => $cacheInfo['total_scraped'] ?? null,
                'total_alive' => $cacheInfo['total_alive'] ?? null,
                'total_dead' => $cacheInfo['total_dead'] ?? null,
                'fastest_latency_ms' => $cacheInfo['fastest_latency_ms'] ?? null,
            ] : null
        ];
    }

    public static function reload(): void {
        self::init(true);
    }
}
