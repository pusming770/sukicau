import React, { useState } from 'react';
import { Gamepad2, ChevronDown, ChevronUp, Ticket } from 'lucide-react';
import { Transaction } from '../types';

interface GamePurchasesViewProps {
  transactions: Transaction[];
}

interface GameGroup {
  key: string;
  name: string;
  icon: string;
  items: Transaction[];
}

interface StackedItem {
  id: string | number;
  name: string;
  thumbnail?: string;
  unitPrice: number;
  totalPrice: number;
  count: number;
  itemType?: string;
}

const GameIconImage: React.FC<{ src?: string; fallbackSrc?: string; name: string }> = ({ src, fallbackSrc, name }) => {
  const [hasError, setHasError] = useState(false);
  const targetSrc = (!hasError && src) ? src : (!hasError && fallbackSrc ? fallbackSrc : null);

  if (!targetSrc || hasError) {
    return <Gamepad2 className="w-6 h-6 text-[#A855F7]" />;
  }

  return (
    <img
      src={targetSrc}
      alt={name}
      loading="lazy"
      onError={() => setHasError(true)}
      className="w-full h-full object-cover"
    />
  );
};

export const GamePurchasesView: React.FC<GamePurchasesViewProps> = ({ transactions }) => {
  const [openGames, setOpenGames] = useState<Record<string, boolean>>({});

  const formatNumber = (num: number) => {
    return new Intl.NumberFormat().format(num);
  };

  // Filter purchases (outgoing)
  const purchases = transactions.filter((tx) => tx.type === 'Purchase' || !tx.income);

  // Group into Game and Non-Game
  const gameMap: Record<string, GameGroup> = {};
  const nonGamePurchases: Transaction[] = [];

  purchases.forEach((tx, idx) => {
    const cleanType = (tx.itemType || '').toLowerCase().replace(/[\s_-]/g, '');
    const isGameType = cleanType === 'gamepass' || cleanType === 'developerproduct' || cleanType === 'badge';
    const isGame = !!(tx.universeId || tx.placeId || (tx.gameName && tx.gameName.trim() !== '') || tx.gameIcon || isGameType);

    if (isGame) {
      const key = tx.universeId
        ? `u_${tx.universeId}`
        : tx.placeId
        ? `p_${tx.placeId}`
        : tx.gameName && tx.gameName.trim() !== ''
        ? `g_${encodeURIComponent(tx.gameName.trim())}`
        : tx.sellerId
        ? `s_${tx.sellerId}`
        : `g_${idx}`;

      const defaultName = tx.gameName || (isGameType ? 'In-Game Experience' : 'Game Experience');

      if (!gameMap[key]) {
        gameMap[key] = {
          key,
          name: defaultName,
          icon: tx.gameIcon || '',
          items: []
        };
      }
      if (tx.gameName && (!gameMap[key].name || gameMap[key].name === 'Game Experience' || gameMap[key].name === 'In-Game Experience')) {
        gameMap[key].name = tx.gameName;
      }
      if (tx.gameIcon && !gameMap[key].icon) {
        gameMap[key].icon = tx.gameIcon;
      }
      gameMap[key].items.push(tx);
    } else {
      nonGamePurchases.push(tx);
    }
  });

  const games = Object.values(gameMap);

  const toggleGame = (key: string) => {
    setOpenGames((prev) => ({ ...prev, [key]: !prev[key] }));
  };

  const stackItems = (items: Transaction[]): StackedItem[] => {
    const map = new Map<string, StackedItem>();
    items.forEach((item) => {
      const itemName = (item.name || item.detail || item.type || 'Gamepass').trim();
      const unitPrice = Math.abs(item.amount);
      const stackKey = item.assetId
        ? `id_${item.assetId}_${unitPrice}`
        : `name_${itemName.toLowerCase()}_${unitPrice}`;

      if (map.has(stackKey)) {
        const existing = map.get(stackKey)!;
        existing.count += 1;
        existing.totalPrice += unitPrice;
        if (!existing.thumbnail && (item.thumbnail || item.creatorAvatar)) {
          existing.thumbnail = item.thumbnail || item.creatorAvatar;
        }
      } else {
        map.set(stackKey, {
          id: item.assetId || stackKey,
          name: itemName,
          thumbnail: item.thumbnail || item.creatorAvatar,
          unitPrice,
          totalPrice: unitPrice,
          count: 1,
          itemType: item.itemType
        });
      }
    });
    return Array.from(map.values());
  };

  return (
    <div className="mb-6">
      <div className="flex items-center gap-2 text-[11px] font-semibold text-white/50 tracking-[0.08em] uppercase mb-3 px-1">
        <Gamepad2 className="w-3.5 h-3.5 text-[#A855F7]" />
        <span>Purchases by Game Experience</span>
        {games.length > 0 && <span className="text-white/30 text-[10.5px]">({games.length} Games)</span>}
      </div>

      {games.length === 0 ? (
        <div className="text-center py-4 text-white/40 text-[12.5px] bg-white/[0.02] border border-white/[0.06] rounded-xl mb-4">
          No game purchases detected.
        </div>
      ) : (
        <div className="flex flex-col gap-2.5 mb-5">
          {games.map((game) => {
            const isOpen = !!openGames[game.key];
            const totalSpent = game.items.reduce((sum, item) => sum + Math.abs(item.amount), 0);
            const stackedPasses = stackItems(game.items);

            return (
              <div
                key={game.key}
                className="bg-white/[0.03] border border-white/[0.08] hover:border-white/15 rounded-2xl overflow-hidden transition-all duration-200"
              >
                {/* Game Header: (game photo) (game name) (total spent on that game) */}
                <div
                  onClick={() => toggleGame(game.key)}
                  className="flex items-center justify-between p-3.5 cursor-pointer hover:bg-white/[0.04] transition-colors select-none gap-3"
                >
                  <div className="flex items-center gap-3 min-w-0 flex-1">
                    <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-white/10 to-white/5 overflow-hidden shrink-0 flex items-center justify-center border border-white/10 shadow-sm">
                      <GameIconImage
                        src={game.icon}
                        fallbackSrc={game.items.find((i) => !!i.thumbnail || !!i.gameIcon)?.thumbnail}
                        name={game.name}
                      />
                    </div>

                    <div className="flex flex-col min-w-0">
                      <div className="text-[13.5px] font-semibold text-white truncate" title={game.name}>
                        {game.name}
                      </div>
                      <div className="text-[11.5px] text-white/50 flex items-center gap-1.5 mt-0.5">
                        <span>{game.items.length} {game.items.length > 1 ? 'items' : 'item'}</span>
                        {stackedPasses.length < game.items.length && (
                          <span className="text-[#A855F7]">({stackedPasses.length} unique)</span>
                        )}
                      </div>
                    </div>
                  </div>

                  <div className="flex items-center gap-3 shrink-0">
                    <div className="flex flex-col items-end">
                      <span className="text-[#FFD60A] font-bold text-[14px] tabular-nums drop-shadow-[0_0_8px_rgba(255,214,10,0.25)]">
                        -{formatNumber(totalSpent)} R$
                      </span>
                      <span className="text-white/40 text-[10.5px]">Total Spent</span>
                    </div>

                    <div className="w-7 h-7 rounded-full bg-white/[0.06] flex items-center justify-center text-white/60">
                      {isOpen ? <ChevronUp className="w-4 h-4 text-white" /> : <ChevronDown className="w-4 h-4" />}
                    </div>
                  </div>
                </div>

                {/* Collapsible Items List: (foto gamepass) (nama gamepass) (harga gamepass) stacked ?x */}
                {isOpen && (
                  <div className="px-3.5 pb-3.5 pt-1 border-t border-white/[0.06] flex flex-col gap-2 bg-black/20">
                    <div className="text-[11px] font-medium text-white/40 px-1 pt-1 uppercase tracking-wider flex items-center justify-between">
                      <span>Purchased Gamepasses & Items</span>
                      <span>Price</span>
                    </div>

                    {stackedPasses.map((item, idx) => (
                      <div
                        key={idx}
                        className="flex items-center justify-between p-2.5 rounded-xl bg-white/[0.025] hover:bg-white/[0.06] border border-white/[0.05] transition-colors gap-3"
                      >
                        <div className="flex items-center gap-3 min-w-0 flex-1">
                          <div className="w-10 h-10 rounded-lg bg-black/40 overflow-hidden shrink-0 flex items-center justify-center border border-white/10 shadow-sm">
                            {item.thumbnail ? (
                              <img
                                src={item.thumbnail}
                                alt={item.name}
                                className="w-full h-full object-cover"
                                loading="lazy"
                              />
                            ) : (
                              <Ticket className="w-5 h-5 text-white/40" />
                            )}
                          </div>

                          <div className="flex items-center gap-2 min-w-0 flex-wrap">
                            <span className="text-white/90 font-medium text-[13px] truncate" title={item.name}>
                              {item.name}
                            </span>
                            {item.count > 1 && (
                              <span className="px-1.5 py-0.5 rounded-md bg-[#A855F7]/20 text-[#A855F7] border border-[#A855F7]/30 font-mono text-[11px] font-bold shrink-0">
                                {item.count}x
                              </span>
                            )}
                          </div>
                        </div>

                        <div className="flex flex-col items-end shrink-0">
                          <span className="text-[#FF453A] font-semibold text-[13px] tabular-nums">
                            -{formatNumber(item.totalPrice)} R$
                          </span>
                          {item.count > 1 && (
                            <span className="text-white/40 text-[10.5px] tabular-nums">
                              @{formatNumber(item.unitPrice)} R$
                            </span>
                          )}
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
};
