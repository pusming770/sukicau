import React from 'react';
import { Card } from '../ui/Card';
import { Button } from '../ui/Button';
import { SegmentedControl } from '../SegmentedControl';
import { ToggleSwitch } from '../ToggleSwitch';
import { CookieInput } from './CookieInput';
import { CookieOutput } from './CookieOutput';
import { DetailsView } from './DetailsView';
import { useCookieRefresher } from '../../hooks/useCookieRefresher';
import { RotateCw, AlertCircle, ShieldAlert, Clock } from 'lucide-react';

interface RefresherCardProps {
  onNotify: (type: 'success' | 'error' | 'warning' | 'info', title: string, message?: string) => void;
}

export const RefresherCard: React.FC<RefresherCardProps> = ({ onNotify }) => {
  const {
    cookieInput,
    setCookieInput,
    refreshedCookie,
    logoutAll,
    setLogoutAll,
    mode,
    setMode,
    isLoading,
    status,
    error,
    details,
    rateLimitNotice,
    statusText,
    submitRefresh,
    clearAll
  } = useCookieRefresher(onNotify);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    await submitRefresh();
  };

  return (
    <Card className="flex flex-col items-center">
      {/* Card Title */}
      <h2 className="text-[20px] sm:text-[22px] font-semibold text-white tracking-tight mb-1 text-center">
        Cookie Refresher
      </h2>
      <p className="text-[13px] text-white/50 text-center mb-5 max-w-sm">
        Perbarui cookie sesi .ROBLOSECURITY tanpa logout.
      </p>

      {/* Mode Selector */}
      <SegmentedControl
        mode={mode}
        onChange={setMode}
        disabled={isLoading}
      />

      {/* Main Refresh Form */}
      <form onSubmit={handleSubmit} className="w-full flex flex-col">
        {/* Input */}
        <CookieInput
          value={cookieInput}
          onChange={setCookieInput}
          disabled={isLoading}
          onClear={clearAll}
        />

        {/* Security Option: Logout All Sessions */}
        <ToggleSwitch
          id="logout-all-sessions"
          checked={logoutAll}
          onChange={setLogoutAll}
          disabled={isLoading}
          label="Keluarkan semua sesi aktif lainnya"
        />

        {/* Live Rate Limit Alert Notice */}
        {isLoading && rateLimitNotice && (
          <div className="w-full mb-4 p-3.5 rounded-xl bg-amber-500/15 border border-amber-500/30 flex items-start gap-2.5 text-[12.5px] text-amber-200 animate-pulse">
            <Clock className="w-4 h-4 shrink-0 mt-0.5 text-amber-400 animate-spin" />
            <div className="flex flex-col">
              <span className="font-semibold text-amber-300">Rate limit Roblox</span>
              <span className="text-white/80 text-[11.5px] mt-0.5">
                {rateLimitNotice.message}
              </span>
              <span className="text-amber-400 text-[11px] mt-1 font-mono">
                Mencoba ulang dalam {rateLimitNotice.waitSeconds} detik (Percobaan {rateLimitNotice.attempt}/5)
              </span>
            </div>
          </div>
        )}

        {/* Live General Status Text */}
        {isLoading && !rateLimitNotice && statusText && (
          <div className="w-full mb-3 text-center text-[12px] text-white/60 animate-pulse">
            {statusText}
          </div>
        )}

        {/* Error Alert Banner */}
        {status === 'error' && error && (
          <div className="w-full mb-4 p-3 rounded-xl bg-[#FF453A]/10 border border-[#FF453A]/25 flex items-start gap-2.5 text-[12.5px] text-[#FF453A] animate-appear">
            <AlertCircle className="w-4 h-4 shrink-0 mt-0.5" />
            <div className="flex flex-col">
              <span className="font-semibold">{error.message}</span>
              {error.code === 'VALIDATION_ERROR' && (
                <span className="text-white/60 text-[11.5px] mt-0.5">
                  Salin seluruh isi cookie dari developer tools browser.
                </span>
              )}
            </div>
          </div>
        )}

        {/* Primary Action Button */}
        <Button
          type="submit"
          variant="primary"
          size="lg"
          isLoading={isLoading}
          leftIcon={<RotateCw className="w-4 h-4" />}
          className="w-full shadow-lg"
        >
          {rateLimitNotice
            ? `Menunggu (${rateLimitNotice.waitSeconds}s)…`
            : (isLoading ? (statusText || 'Memproses…') : 'Refresh Cookie')}
        </Button>
      </form>

      {/* Refreshed Output Panel */}
      <CookieOutput
        cookie={refreshedCookie}
        onCopySuccess={() => onNotify('success', 'Disalin', 'Cookie baru telah disalin ke clipboard.')}
      />

      {/* Detailed Mode View */}
      {mode === 'detailed' && details && (
        <DetailsView details={details} />
      )}

      {/* Security Reassurance Footnote */}
      <div className="mt-5 pt-4 border-t border-white/[0.06] w-full flex items-center justify-center gap-1.5 text-[11.5px] text-white/35">
        <ShieldAlert className="w-3.5 h-3.5 text-white/40" />
        <span>Diproses langsung di memori dan tidak disimpan ke server.</span>
      </div>
    </Card>
  );
};
