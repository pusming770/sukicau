import React, { useState } from 'react';
import { AccountDetails } from '../../types';
import { Badge } from '../ui/Badge';
import { ShieldCheck, User, Mail, Phone, Lock, Sparkles, Calendar, Users, Eye, CircleUser } from 'lucide-react';

interface AccountSummaryProps {
  details: AccountDetails;
}

export const AccountSummary: React.FC<AccountSummaryProps> = ({ details }) => {
  const [avatarError, setAvatarError] = useState(false);
  const [fullAvatarError, setFullAvatarError] = useState(false);
  const [avatarView, setAvatarView] = useState<'full' | 'headshot'>(
    details.fullAvatarUrl ? 'full' : 'headshot'
  );

  const hasFullAvatar = !!details.fullAvatarUrl && !fullAvatarError;
  const showFullAvatar = avatarView === 'full' && hasFullAvatar;

  return (
    <div className="w-full flex flex-col items-center">
      {/* Avatar Showcase Container */}
      <div className="relative mb-5 flex flex-col items-center w-full">
        {showFullAvatar ? (
          /* Full Body 3D Avatar (Responsive across all mobile screen ratios) */
          <div className="relative w-full max-w-[240px] sm:max-w-[280px] md:max-w-[320px] aspect-[3/4] max-h-72 sm:max-h-80 md:max-h-96 flex items-center justify-center mx-auto group">
            {/* Ambient Radial Glow */}
            <div className="absolute inset-0 rounded-3xl bg-gradient-to-b from-[#A855F7]/10 via-[#BF5AF2]/5 to-transparent blur-xl pointer-events-none" />
            <div className="absolute -bottom-2 w-3/4 h-8 bg-black/40 rounded-full blur-md" />

            <img
              src={details.fullAvatarUrl}
              alt={`${details.username}'s Full Avatar`}
              loading="lazy"
              onError={() => {
                setFullAvatarError(true);
                setAvatarView('headshot');
              }}
              className="w-full h-full object-contain relative z-10 drop-shadow-[0_12px_28px_rgba(0,0,0,0.7)] group-hover:scale-105 transition-transform duration-300"
            />

            {details.premium && (
              <span
                className="absolute top-2 right-2 z-20 p-1.5 rounded-full bg-[#FFD60A] text-black shadow-lg ring-2 ring-black/40"
                title="Premium Member"
              >
                <Sparkles className="w-3.5 h-3.5 fill-black" />
              </span>
            )}
          </div>
        ) : (
          /* Circle Headshot Avatar */
          <div className="relative my-2 group">
            {details.avatarUrl && !avatarError ? (
              <img
                src={details.avatarUrl}
                alt={`${details.username}'s Avatar`}
                loading="lazy"
                onError={() => setAvatarError(true)}
                className="w-24 h-24 rounded-full object-cover shadow-[0_8px_24px_rgba(0,0,0,0.5)] border-2 border-white/20 transition-transform duration-300 group-hover:scale-105"
              />
            ) : (
              <div className="w-24 h-24 rounded-full bg-white/10 border-2 border-white/20 flex items-center justify-center text-white/50">
                <User className="w-10 h-10" />
              </div>
            )}
            {details.premium && (
              <span
                className="absolute bottom-0 right-0 p-1.5 rounded-full bg-[#FFD60A] text-black shadow-md ring-2 ring-[#16161C]"
                title="Premium Member"
              >
                <Sparkles className="w-3.5 h-3.5 fill-black" />
              </span>
            )}
          </div>
        )}

        {/* View Switcher Pill (Full Body vs Headshot) */}
        {hasFullAvatar && (
          <div className="mt-2.5 inline-flex p-0.5 rounded-full bg-white/[0.06] border border-white/10 shadow-sm backdrop-blur-md">
            <button
              type="button"
              onClick={() => setAvatarView('full')}
              className={`flex items-center gap-1.5 px-3 py-1 rounded-full text-[11.5px] font-medium transition-all ${
                avatarView === 'full'
                  ? 'bg-[#A855F7] text-white shadow-sm'
                  : 'text-white/60 hover:text-white'
              }`}
            >
              <Eye className="w-3 h-3" />
              <span>Full Avatar</span>
            </button>
            <button
              type="button"
              onClick={() => setAvatarView('headshot')}
              className={`flex items-center gap-1.5 px-3 py-1 rounded-full text-[11.5px] font-medium transition-all ${
                avatarView === 'headshot'
                  ? 'bg-[#A855F7] text-white shadow-sm'
                  : 'text-white/60 hover:text-white'
              }`}
            >
              <CircleUser className="w-3 h-3" />
              <span>Headshot</span>
            </button>
          </div>
        )}
      </div>

      {/* iOS Grouped List Table */}
      <div className="w-full rounded-2xl bg-white/[0.03] border border-white/10 px-3.5 py-1 mb-5">
        {/* Username */}
        <div className="flex items-center justify-between py-2.5 border-b border-white/[0.06] text-[13.5px]">
          <span className="text-white/60 font-normal flex items-center gap-2">
            <User className="w-3.5 h-3.5 text-white/40" />
            <span>Username</span>
          </span>
          <span className="text-white font-medium break-all">{details.username || 'N/A'}</span>
        </div>

        {/* Display Name */}
        <div className="flex items-center justify-between py-2.5 border-b border-white/[0.06] text-[13.5px]">
          <span className="text-white/60 font-normal flex items-center gap-2">
            <Sparkles className="w-3.5 h-3.5 text-white/40" />
            <span>Display Name</span>
          </span>
          <span className="text-white font-medium break-all">{details.displayName || 'N/A'}</span>
        </div>

        {/* Age Group */}
        <div className="flex items-center justify-between py-2.5 border-b border-white/[0.06] text-[13.5px]">
          <span className="text-white/60 font-normal flex items-center gap-2">
            <Users className="w-3.5 h-3.5 text-white/40" />
            <span>Age Group</span>
          </span>
          <div className="flex items-center gap-2">
            <span className="text-white font-medium">{details.ageGroup || 'N/A'}</span>
            <Badge variant={details.ageGroupChecked ? 'success' : 'neutral'}>
              {details.ageGroupStatus || (details.ageGroupChecked ? 'Checked' : 'Unchecked')}
            </Badge>
          </div>
        </div>

        {/* Birthday (M, D, Y) */}
        <div className="flex items-center justify-between py-2.5 border-b border-white/[0.06] text-[13.5px]">
          <span className="text-white/60 font-normal flex items-center gap-2">
            <Calendar className="w-3.5 h-3.5 text-white/40" />
            <span>Birthday</span>
          </span>
          <div className="flex items-center gap-2">
            <span className="text-white font-medium">{details.birthday || 'N/A'}</span>
            <Badge variant={details.birthdayVerified ? 'success' : 'neutral'}>
              {details.birthdayStatus || (details.birthdayVerified ? 'Verified' : 'Non Verified')}
            </Badge>
          </div>
        </div>

        {/* Email */}
        <div className="flex items-center justify-between py-2.5 border-b border-white/[0.06] text-[13.5px]">
          <span className="text-white/60 font-normal flex items-center gap-2">
            <Mail className="w-3.5 h-3.5 text-white/40" />
            <span>Email</span>
          </span>
          <span className="text-white font-medium break-all text-right">{details.email || 'Not available'}</span>
        </div>

        {/* Email Verified */}
        <div className="flex items-center justify-between py-2.5 border-b border-white/[0.06] text-[13.5px]">
          <span className="text-white/60 font-normal flex items-center gap-2">
            <ShieldCheck className="w-3.5 h-3.5 text-white/40" />
            <span>Email Status</span>
          </span>
          <Badge variant={details.emailVerified ? 'success' : 'neutral'}>
            {details.emailVerified ? 'Verified' : 'Unverified'}
          </Badge>
        </div>

        {/* Phone */}
        <div className="flex items-center justify-between py-2.5 border-b border-white/[0.06] text-[13.5px]">
          <span className="text-white/60 font-normal flex items-center gap-2">
            <Phone className="w-3.5 h-3.5 text-white/40" />
            <span>Phone</span>
          </span>
          <span className="text-white font-medium">{details.phone || 'Not available'}</span>
        </div>

        {/* 2SV Method */}
        <div className="flex items-center justify-between py-2.5 border-b border-white/[0.06] text-[13.5px]">
          <span className="text-white/60 font-normal flex items-center gap-2">
            <Lock className="w-3.5 h-3.5 text-white/40" />
            <span>2SV Method</span>
          </span>
          <Badge variant={details.twoFactor && details.twoFactor !== 'None' ? 'info' : 'neutral'}>
            {details.twoFactor || details.twoFA || 'None'}
          </Badge>
        </div>

        {/* Premium */}
        <div className="flex items-center justify-between py-2.5 text-[13.5px]">
          <span className="text-white/60 font-normal flex items-center gap-2">
            <Sparkles className="w-3.5 h-3.5 text-[#FFD60A]" />
            <span>Membership</span>
          </span>
          <Badge variant={details.premium ? 'premium' : 'neutral'}>
            {details.premium ? 'Roblox Premium' : 'Free Tier'}
          </Badge>
        </div>
      </div>
    </div>
  );
};
