import React from 'react';
import { AnimationAsset, LimitedItem, SFXItem } from '../../types';
import { Sparkles, Gem, Package, Flame, Volume2, CloudFog, Zap } from 'lucide-react';

interface AssetsGridProps {
  animations?: AnimationAsset[];
  limitedItems?: LimitedItem[];
  sfxItems?: SFXItem[];
}

export const AssetsGrid: React.FC<AssetsGridProps> = ({
  animations = [],
  limitedItems = [],
  sfxItems = []
}) => {
  const getEffectBadge = (effectType: string) => {
    switch (effectType) {
      case 'Fire':
        return (
          <span className="inline-flex items-center gap-1 px-1.5 py-0.5 rounded-md text-[10px] font-semibold bg-[#FF453A]/20 text-[#FF453A] border border-[#FF453A]/30">
            <Flame className="w-2.5 h-2.5" /> Fire
          </span>
        );
      case 'Sparkles':
        return (
          <span className="inline-flex items-center gap-1 px-1.5 py-0.5 rounded-md text-[10px] font-semibold bg-[#FFD60A]/20 text-[#FFD60A] border border-[#FFD60A]/30">
            <Sparkles className="w-2.5 h-2.5" /> Sparkles
          </span>
        );
      case 'Smoke':
        return (
          <span className="inline-flex items-center gap-1 px-1.5 py-0.5 rounded-md text-[10px] font-semibold bg-white/15 text-white/80 border border-white/20">
            <CloudFog className="w-2.5 h-2.5" /> Smoke
          </span>
        );
      case 'Sound':
        return (
          <span className="inline-flex items-center gap-1 px-1.5 py-0.5 rounded-md text-[10px] font-semibold bg-[#A855F7]/20 text-[#A855F7] border border-[#A855F7]/30">
            <Volume2 className="w-2.5 h-2.5" /> SFX Audio
          </span>
        );
      default:
        return (
          <span className="inline-flex items-center gap-1 px-1.5 py-0.5 rounded-md text-[10px] font-semibold bg-[#BF5AF2]/20 text-[#BF5AF2] border border-[#BF5AF2]/30">
            <Zap className="w-2.5 h-2.5" /> Special Effect
          </span>
        );
    }
  };

  return (
    <div className="w-full flex flex-col gap-5 mb-6">
      {/* SFX Items Section */}
      <div>
        <div className="flex items-center justify-between mb-2.5 ml-1">
          <div className="flex items-center gap-1.5 text-[11px] font-semibold text-white/50 uppercase tracking-wider">
            <Sparkles className="w-3.5 h-3.5 text-[#FFD60A]" />
            <span>SFX Items (Special Effects)</span>
            {sfxItems.length > 0 && (
              <span className="text-[#FFD60A]/90 font-mono text-[10.5px]">({sfxItems.length})</span>
            )}
          </div>
        </div>

        {sfxItems.length > 0 ? (
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-2.5">
            {sfxItems.map((item, idx) => (
              <div
                key={`${item.assetId}-${idx}`}
                className="group flex flex-col items-center p-2.5 rounded-xl bg-white/[0.03] border border-white/10 hover:border-white/20 hover:bg-white/[0.06] transition-all relative overflow-hidden"
              >
                <div className="w-16 h-16 rounded-lg bg-black/40 overflow-hidden mb-2 flex items-center justify-center border border-white/5 shadow-inner">
                  {item.thumbnail ? (
                    <img
                      src={item.thumbnail}
                      alt={item.name}
                      loading="lazy"
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform"
                    />
                  ) : (
                    <Sparkles className="w-7 h-7 text-[#FFD60A]/50" />
                  )}
                </div>
                <span
                  className="text-[12px] text-white/90 font-medium text-center truncate w-full mb-1.5"
                  title={item.name}
                >
                  {item.name}
                </span>
                <div className="mt-auto flex flex-col items-center gap-1">
                  {getEffectBadge(item.effectType)}
                  {item.rap && item.rap > 0 ? (
                    <span className="text-[10.5px] font-bold text-[#FFD60A]">
                      {new Intl.NumberFormat().format(item.rap)} R$
                    </span>
                  ) : null}
                </div>
              </div>
            ))}
          </div>
        ) : (
          <div className="rounded-xl bg-white/[0.02] border border-white/5 p-4 text-center text-white/40 text-[12px]">
            No special effect (SFX) items detected on this account.
          </div>
        )}
      </div>

      {/* Limited Items Section */}
      <div>
        <div className="flex items-center gap-1.5 text-[11px] font-semibold text-white/50 uppercase tracking-wider mb-2.5 ml-1">
          <Gem className="w-3.5 h-3.5 text-[#FF9F0A]" />
          <span>Limited Collectibles ({limitedItems.length})</span>
        </div>

        {limitedItems.length > 0 ? (
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-2.5">
            {limitedItems.map((item, idx) => (
              <div
                key={`${item.assetId}-${idx}`}
                className="group flex flex-col items-center p-2.5 rounded-xl bg-white/[0.03] border border-white/10 hover:border-white/20 hover:bg-white/[0.06] transition-all"
              >
                <div className="w-16 h-16 rounded-lg bg-black/40 overflow-hidden mb-2 flex items-center justify-center">
                  {item.thumbnail ? (
                    <img
                      src={item.thumbnail}
                      alt={item.name}
                      loading="lazy"
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform"
                    />
                  ) : (
                    <Gem className="w-7 h-7 text-white/30" />
                  )}
                </div>
                <span
                  className="text-[12px] text-white/90 font-medium text-center truncate w-full mb-1"
                  title={item.name}
                >
                  {item.name}
                </span>
                <span className="text-[11px] font-bold text-[#FFD60A]">
                  {item.recentAveragePrice ? `${new Intl.NumberFormat().format(item.recentAveragePrice)} R$` : '0 R$'}
                </span>
              </div>
            ))}
          </div>
        ) : (
          <div className="rounded-xl bg-white/[0.02] border border-white/5 p-4 text-center text-white/40 text-[12px]">
            No limited items detected on this account.
          </div>
        )}
      </div>

      {/* Animations Section */}
      <div>
        <div className="flex items-center gap-1.5 text-[11px] font-semibold text-white/50 uppercase tracking-wider mb-2.5 ml-1">
          <Package className="w-3.5 h-3.5 text-[#BF5AF2]" />
          <span>Animation Packs ({animations.length})</span>
        </div>

        {animations.length > 0 ? (
          <div className="grid grid-cols-3 sm:grid-cols-4 md:grid-cols-5 gap-2.5">
            {animations.map((anim, idx) => (
              <div
                key={`${anim.id}-${idx}`}
                className="group flex flex-col items-center p-2 rounded-xl bg-white/[0.03] border border-white/10 hover:border-white/20 hover:bg-white/[0.06] transition-all"
              >
                <div className="w-14 h-14 rounded-lg bg-black/40 overflow-hidden mb-1.5 flex items-center justify-center relative">
                  {anim.thumbnail ? (
                    <img
                      src={anim.thumbnail}
                      alt={anim.name}
                      loading="lazy"
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform"
                      onError={(e) => {
                        (e.target as HTMLElement).style.display = 'none';
                        const parent = (e.target as HTMLElement).parentElement;
                        if (parent && !parent.querySelector('.anim-fallback-icon')) {
                          const icon = document.createElement('div');
                          icon.className = 'anim-fallback-icon flex items-center justify-center text-white/30';
                          icon.innerHTML = '<svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="m7.5 4.27 9 5.15"/><path d="M21 8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16Z"/><path d="m3.3 7 8.7 5 8.7-5"/><path d="M12 22V12"/></svg>';
                          parent.appendChild(icon);
                        }
                      }}
                    />
                  ) : (
                    <Package className="w-6 h-6 text-white/30" />
                  )}
                </div>
                <span
                  className="text-[11.5px] text-white/80 font-medium text-center truncate w-full"
                  title={anim.name}
                >
                  {anim.name}
                </span>
              </div>
            ))}
          </div>
        ) : (
          <div className="rounded-xl bg-white/[0.02] border border-white/5 p-4 text-center text-white/40 text-[12px]">
            No animation packs found.
          </div>
        )}
      </div>
    </div>
  );
};
