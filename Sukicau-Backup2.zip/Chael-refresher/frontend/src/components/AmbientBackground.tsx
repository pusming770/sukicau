import React from 'react';

export const AmbientBackground: React.FC = () => {
  return (
    <div className="fixed inset-0 pointer-events-none overflow-hidden z-0" aria-hidden="true">
      {/* Top Ambient Glow */}
      <div 
        className="absolute w-[clamp(300px,50vw,560px)] h-[clamp(300px,50vw,560px)] -top-[140px] left-1/2 -translate-x-1/2 rounded-full blur-[110px] opacity-45 pointer-events-none animate-float-1"
        style={{
          background: 'radial-gradient(circle, rgba(168, 85, 247, 0.35) 0%, rgba(236, 72, 153, 0.2) 50%, transparent 70%)'
        }}
      />
      {/* Bottom Ambient Glow */}
      <div 
        className="absolute w-[clamp(280px,45vw,500px)] h-[clamp(280px,45vw,500px)] -bottom-[130px] left-1/2 -translate-x-[40%] rounded-full blur-[110px] opacity-45 pointer-events-none animate-float-2"
        style={{
          background: 'radial-gradient(circle, rgba(236, 72, 153, 0.25) 0%, rgba(168, 85, 247, 0.15) 50%, transparent 70%)'
        }}
      />
    </div>
  );
};
