
#!/usr/bin/env bash
set -euo pipefail

DOMAIN="sukicau.my.id"
WEB_ROOT="/var/www/Chael-refresher"
SITE="chael-refresher"
CONF="/etc/nginx/sites-available/$SITE"
ENABLED="/etc/nginx/sites-enabled/$SITE"

if [ ! -f "$WEB_ROOT/index.html" ]; then
    echo "ERROR: $WEB_ROOT/index.html tidak ditemukan."
    exit 1
fi

echo "== Installing Nginx, PHP-FPM and Certbot =="

apt-get update
apt-get install -y nginx php-fpm php-cli php-curl \
    php-mbstring php-xml php-zip php-mysql \
    certbot python3-certbot-nginx curl

# Detect PHP-FPM socket
PHP_SOCKET="$(find /run/php -maxdepth 1 -type s \
    -name 'php*-fpm.sock' -print -quit)"

if [ -z "$PHP_SOCKET" ]; then
    echo "ERROR: PHP-FPM socket tidak ditemukan."
    exit 1
fi

# Set basic website permissions
chmod 755 /var/www "$WEB_ROOT"
find "$WEB_ROOT" -type d -exec chmod 755 {} \;
find "$WEB_ROOT" -type f -exec chmod 644 {} \;

# Create HTTP configuration, ready for Certbot
cat > "$CONF" <<NGINX
server {
    listen 80;
    server_name ${DOMAIN};

    root ${WEB_ROOT};
    index index.html index.php index.htm;

    access_log /var/log/nginx/chael-refresher-access.log;
    error_log /var/log/nginx/chael-refresher-error.log;

    location ^~ /.well-known/acme-challenge/ {
        allow all;
        default_type "text/plain";
        try_files \$uri =404;
    }

    location / {
        try_files \$uri \$uri/ =404;
    }

    location ~ \.php$ {
        try_files \$uri =404;
        include fastcgi_params;
        fastcgi_param SCRIPT_FILENAME \$document_root\$fastcgi_script_name;
        fastcgi_param DOCUMENT_ROOT \$document_root;
        fastcgi_pass unix:${PHP_SOCKET};
    }

    location ~ /\.(?!well-known).* {
        deny all;
    }
}

server {
    listen 0.0.0.0:2370;
    server_name ${DOMAIN} _;

    root ${WEB_ROOT};
    index index.html index.php index.htm;

    location / {
        try_files \$uri \$uri/ =404;
    }

    location ~ \.php$ {
        try_files \$uri =404;
        include fastcgi_params;
        fastcgi_param SCRIPT_FILENAME \$document_root\$fastcgi_script_name;
        fastcgi_param DOCUMENT_ROOT \$document_root;
        fastcgi_pass unix:${PHP_SOCKET};
    }

    location ~ /\.(?!well-known).* {
        deny all;
    }
}
NGINX

ln -sfn "$CONF" "$ENABLED"
rm -f /etc/nginx/sites-enabled/default

nginx -t
systemctl enable nginx
systemctl restart nginx

# Open ports when UFW is active
if command -v ufw >/dev/null 2>&1 &&
   ufw status | grep -q "Status: active"; then
    ufw allow 80/tcp
    ufw allow 443/tcp
    ufw allow 2370/tcp
fi

echo
echo "== DNS pre-check =="
echo "Make sure ${DOMAIN} points to this VPS public IPv4."
echo "Make sure TCP ports 80 and 443 are reachable."
echo

read -r -p "DNS sudah benar dan port 80/443 terbuka? Ketik YES: " CONFIRM
if [ "$CONFIRM" != "YES" ]; then
    echo "Konfigurasi HTTP siap. Jalankan script lagi setelah DNS dan firewall siap."
    exit 0
fi

read -r -p "Email untuk notifikasi sertifikat: " EMAIL
if [ -z "$EMAIL" ]; then
    echo "Email wajib diisi."
    exit 1
fi

# Issue and install SSL certificate
certbot --nginx \
    -d "$DOMAIN" \
    --email "$EMAIL" \
    --agree-tos \
    --no-eff-email \
    --redirect

echo
echo "== Testing Nginx and SSL =="
nginx -t
systemctl reload nginx
certbot renew --dry-run

echo
echo "Setup complete!"
echo "HTTPS: https://${DOMAIN}"
echo "HTTP : http://${DOMAIN} (redirects to HTTPS)"
echo "Port 2370 remains configured."

