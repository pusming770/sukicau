import React from 'react';
import { Coins, TrendingUp, TrendingDown, Clock, CreditCard } from 'lucide-react';
import { AccountDetails } from '../types';

interface EconomyBentoProps {
  details: AccountDetails;
}

export const EconomyBento: React.FC<EconomyBentoProps> = ({ details }) => {
  const yearlyTotals = details.yearlyTotals || {};

  return (
    <div className="mb-6">
      <div className="flex items-center gap-2 text-[11px] font-semibold text-white/50 tracking-[0.08em] uppercase mb-3 px-1">
        <Coins className="w-3.5 h-3.5 text-[#FFD60A]" />
        <span>Economy Overview</span>
      </div>

      {/* Main Economy Bento Grid */}
      <div className="grid grid-cols-2 sm:grid-cols-3 gap-2.5 mb-4">
        {/* Robux Balance */}
        <div className="bg-white/[0.03] border border-white/[0.08] hover:border-white/15 hover:bg-white/[0.05] transition-all duration-200 rounded-2xl p-3.5 flex flex-col justify-between">
          <div className="text-[11px] font-medium text-white/50 uppercase tracking-wider mb-1 flex items-center justify-between">
            <span>Robux</span>
            <Coins className="w-3.5 h-3.5 text-[#FFD60A]" />
          </div>
          <div className="text-[19px] font-bold text-[#FFD60A] tracking-tight">
            {details.robux.toLocaleString()} <span className="text-[12px] font-normal text-white/50">R$</span>
          </div>
        </div>

        {/* Pending Robux */}
        <div className="bg-white/[0.03] border border-white/[0.08] hover:border-white/15 hover:bg-white/[0.05] transition-all duration-200 rounded-2xl p-3.5 flex flex-col justify-between">
          <div className="text-[11px] font-medium text-white/50 uppercase tracking-wider mb-1 flex items-center justify-between">
            <span>Pending</span>
            <Clock className="w-3.5 h-3.5 text-white/40" />
          </div>
          <div className="text-[19px] font-bold text-white tracking-tight">
            {details.pendingRobux.toLocaleString()} <span className="text-[12px] font-normal text-white/50">R$</span>
          </div>
        </div>

        {/* RAP Total */}
        <div className="bg-white/[0.03] border border-white/[0.08] hover:border-white/15 hover:bg-white/[0.05] transition-all duration-200 rounded-2xl p-3.5 flex flex-col justify-between col-span-2 sm:col-span-1">
          <div className="text-[11px] font-medium text-white/50 uppercase tracking-wider mb-1 flex items-center justify-between">
            <span>RAP Total</span>
            <span className="text-[10px] px-1.5 py-0.5 rounded bg-[#FFD60A]/10 text-[#FFD60A] font-semibold">Value</span>
          </div>
          <div className="text-[19px] font-bold text-[#FFD60A] tracking-tight">
            {details.totalRAP.toLocaleString()} <span className="text-[12px] font-normal text-white/50">R$</span>
          </div>
        </div>

        {/* Account Credit */}
        <div className="bg-white/[0.03] border border-white/[0.08] hover:border-white/15 hover:bg-white/[0.05] transition-all duration-200 rounded-2xl p-3.5 flex flex-col justify-between">
          <div className="text-[11px] font-medium text-white/50 uppercase tracking-wider mb-1 flex items-center justify-between">
            <span>Credit</span>
            <CreditCard className="w-3.5 h-3.5 text-white/40" />
          </div>
          <div className="text-[17px] font-bold text-white/90 tracking-tight">
            {details.accountCredit !== null ? details.accountCredit : 0} <span className="text-[11px] font-normal text-white/40">Credits</span>
          </div>
        </div>

        {/* Incoming (Year) */}
        <div className="bg-white/[0.03] border border-white/[0.08] hover:border-white/15 hover:bg-white/[0.05] transition-all duration-200 rounded-2xl p-3.5 flex flex-col justify-between">
          <div className="text-[11px] font-medium text-white/50 uppercase tracking-wider mb-1 flex items-center justify-between">
            <span>Annual In</span>
            <TrendingUp className="w-3.5 h-3.5 text-[#30D158]" />
          </div>
          <div className="text-[17px] font-bold text-[#30D158] tracking-tight">
            +{(details.incomingYear || 0).toLocaleString()} <span className="text-[11px] font-normal text-white/50">R$</span>
          </div>
        </div>

        {/* Outgoing (Year) */}
        <div className="bg-white/[0.03] border border-white/[0.08] hover:border-white/15 hover:bg-white/[0.05] transition-all duration-200 rounded-2xl p-3.5 flex flex-col justify-between col-span-2 sm:col-span-1">
          <div className="text-[11px] font-medium text-white/50 uppercase tracking-wider mb-1 flex items-center justify-between">
            <span>Annual Out</span>
            <TrendingDown className="w-3.5 h-3.5 text-[#FF453A]" />
          </div>
          <div className="text-[17px] font-bold text-[#FF453A] tracking-tight">
            -{(details.outgoingYear || 0).toLocaleString()} <span className="text-[11px] font-normal text-white/50">R$</span>
          </div>
        </div>
      </div>

      {/* Yearly Summary Categories */}
      {yearlyTotals && Object.keys(yearlyTotals).length > 0 && (
        <div className="mb-4">
          <div className="text-[10.5px] font-medium text-white/40 uppercase tracking-wider mb-2 px-1">
            Yearly Categorized Totals
          </div>
          <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
            {Object.entries(yearlyTotals).map(([key, val]) => {
              if (typeof val !== 'number') return null;
              const k = key.toLowerCase();
              const isOut = k.includes('out') || k.includes('cost') || k.includes('spend') || k.includes('purchase');
              const isIn = k.includes('in') || k.includes('income') || k.includes('sale') || k.includes('stipend') || k.includes('payout');
              const formattedLabel = key.replace(/([A-Z])/g, ' $1').replace(/^./, str => str.toUpperCase());

              return (
                <div key={key} className="bg-white/[0.02] border border-white/[0.06] rounded-xl p-2.5 text-center">
                  <div className="text-[10px] text-white/40 uppercase tracking-tight truncate mb-1" title={formattedLabel}>
                    {formattedLabel}
                  </div>
                  <div className={`text-[13.5px] font-semibold ${
                    isIn ? 'text-[#30D158]' : isOut ? 'text-[#FF453A]' : 'text-white'
                  }`}>
                    {val.toLocaleString()} R$
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* Overall Totals */}
      <div className="grid grid-cols-2 gap-2.5">
        <div className="bg-white/[0.02] border border-white/[0.06] rounded-xl p-3 text-center">
          <div className="text-[10.5px] text-white/40 uppercase tracking-wider mb-1">Total Income</div>
          <div className="text-[15px] font-bold text-[#30D158]">
            +{details.totalIncome.toLocaleString()} R$
          </div>
        </div>
        <div className="bg-white/[0.02] border border-white/[0.06] rounded-xl p-3 text-center">
          <div className="text-[10.5px] text-white/40 uppercase tracking-wider mb-1">Total Outgoing</div>
          <div className="text-[15px] font-bold text-[#FF453A]">
            -{details.totalOutgoing.toLocaleString()} R$
          </div>
        </div>
      </div>
    </div>
  );
};
