/** @type {import('tailwindcss').Config} */
export default {
  content: [
    "./index.html",
    "./src/**/*.{js,ts,jsx,tsx}",
  ],
  theme: {
    extend: {
      colors: {
        apple: {
          bg: '#0a0612',
          surface: 'rgba(30, 18, 42, 0.72)',
          border: 'rgba(255, 255, 255, 0.08)',
          blue: '#A855F7',
          green: '#30D158',
          yellow: '#FFD60A',
          orange: '#FF9F0A',
          red: '#FF453A',
          purple: '#EC4899'
        }
      },
      fontFamily: {
        sans: [
          '-apple-system',
          'BlinkMacSystemFont',
          '"SF Pro Text"',
          '"SF Pro Display"',
          'Inter',
          'system-ui',
          'sans-serif'
        ],
        mono: [
          'SF Mono',
          'Menlo',
          'Monaco',
          'Consolas',
          'monospace'
        ]
      },
      backdropBlur: {
        'apple': '40px'
      }
    },
  },
  plugins: [],
}
