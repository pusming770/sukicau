import React, { useState } from 'react';
import { Eye, EyeOff, Clipboard, Trash2 } from 'lucide-react';

interface CookieInputProps {
  value: string;
  onChange: (value: string) => void;
  disabled?: boolean;
  onClear: () => void;
}

export const CookieInput: React.FC<CookieInputProps> = ({
  value,
  onChange,
  disabled = false,
  onClear
}) => {
  const [isMasked, setIsMasked] = useState<boolean>(true);

  const handlePaste = async () => {
    try {
      if (navigator.clipboard && window.isSecureContext) {
        const text = await navigator.clipboard.readText();
        if (text) {
          onChange(text);
        }
      }
    } catch {
      // In case clipboard permission is denied, focus textarea
      const el = document.getElementById('current-cookie-input');
      el?.focus();
    }
  };

  const charCount = value.trim().length;

  return (
    <div className="flex flex-col gap-1.5 mb-4 w-full">
      <div className="flex items-center justify-between">
        <label
          htmlFor="current-cookie-input"
          className="text-[13px] font-semibold text-white/90 tracking-tight flex items-center gap-2"
        >
          <span>Cookie Saat Ini</span>
          {charCount > 0 && (
            <span className="text-[11px] font-normal text-white/40">
              ({charCount} karakter)
            </span>
          )}
        </label>

        <div className="flex items-center gap-1">
          {/* Mask / Unmask toggle */}
          {charCount > 0 && (
            <button
              type="button"
              onClick={() => setIsMasked(!isMasked)}
              disabled={disabled}
              className="p-1 text-white/40 hover:text-white transition-colors rounded-md text-[11px] flex items-center gap-1 outline-none"
              title={isMasked ? 'Tampilkan karakter' : 'Sembunyikan karakter'}
              aria-label={isMasked ? 'Tampilkan karakter' : 'Sembunyikan karakter'}
            >
              {isMasked ? <Eye className="w-3.5 h-3.5" /> : <EyeOff className="w-3.5 h-3.5" />}
              <span className="hidden sm:inline">{isMasked ? 'Lihat' : 'Tutup'}</span>
            </button>
          )}

          {/* Paste button */}
          <button
            type="button"
            onClick={handlePaste}
            disabled={disabled}
            className="p-1 text-white/40 hover:text-[#A855F7] transition-colors rounded-md text-[11px] flex items-center gap-1 outline-none ml-1"
            title="Tempel dari clipboard"
          >
            <Clipboard className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">Tempel</span>
          </button>

          {/* Clear button */}
          {charCount > 0 && (
            <button
              type="button"
              onClick={onClear}
              disabled={disabled}
              className="p-1 text-white/40 hover:text-[#FF453A] transition-colors rounded-md text-[11px] flex items-center gap-1 outline-none ml-1"
              title="Hapus input"
            >
              <Trash2 className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">Hapus</span>
            </button>
          )}
        </div>
      </div>

      <div className="relative w-full">
        <textarea
          id="current-cookie-input"
          rows={3}
          value={value}
          disabled={disabled}
          onChange={(e) => onChange(e.target.value)}
          placeholder="Tempel cookie .ROBLOSECURITY di sini…"
          autoComplete="off"
          autoCorrect="off"
          autoCapitalize="off"
          spellCheck="false"
          className={`w-full rounded-2xl bg-black/40 border border-white/10 hover:border-white/20 focus:border-[#A855F7] focus:ring-2 focus:ring-[#A855F7]/25 text-white placeholder-white/30 text-[13px] font-mono leading-relaxed p-3.5 outline-none transition-all duration-200 resize-none ${
            isMasked && charCount > 0 ? 'text-security-disc' : ''
          }`}
          style={isMasked && charCount > 0 ? ({ WebkitTextSecurity: 'disc' } as React.CSSProperties) : {}}
        />
      </div>
    </div>
  );
};
