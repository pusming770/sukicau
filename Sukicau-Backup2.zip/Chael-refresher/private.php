<?php
declare(strict_types=1);

/**
 * Langgor · Private Refresher Endpoint
 * Alias gateway maintaining backward compatibility.
 */
require_once __DIR__ . '/index.php';
