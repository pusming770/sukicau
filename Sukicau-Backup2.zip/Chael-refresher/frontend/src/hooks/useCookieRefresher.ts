import { useState, useCallback, useRef, useEffect } from 'react';
import { RefresherMode, AccountDetails, AppError, RateLimitNotice } from '../types';
import { refresherApi } from '../services/refresherApi';
import { validateCookie } from '../validation/cookieValidator';

export interface UseCookieRefresherReturn {
  cookieInput: string;
  setCookieInput: (val: string) => void;
  refreshedCookie: string;
  logoutAll: boolean;
  setLogoutAll: (val: boolean) => void;
  mode: RefresherMode;
  setMode: (mode: RefresherMode) => void;
  isLoading: boolean;
  status: 'idle' | 'loading' | 'success' | 'error';
  error: AppError | null;
  details: AccountDetails | null;
  rateLimitNotice: RateLimitNotice | null;
  statusText: string | null;
  submitRefresh: () => Promise<boolean>;
  clearAll: () => void;
}

export function useCookieRefresher(
  onNotify?: (type: 'success' | 'error' | 'warning' | 'info', title: string, message?: string) => void
): UseCookieRefresherReturn {
  const [cookieInput, setCookieInput] = useState<string>('');
  const [refreshedCookie, setRefreshedCookie] = useState<string>('');
  const [logoutAll, setLogoutAll] = useState<boolean>(false);
  const [mode, setMode] = useState<RefresherMode>('basic');
  const [status, setStatus] = useState<'idle' | 'loading' | 'success' | 'error'>('idle');
  const [error, setError] = useState<AppError | null>(null);
  const [details, setDetails] = useState<AccountDetails | null>(null);
  const [rateLimitNotice, setRateLimitNotice] = useState<RateLimitNotice | null>(null);
  const [statusText, setStatusText] = useState<string | null>(null);

  const abortControllerRef = useRef<AbortController | null>(null);

  // Clean up any in-flight requests on unmount
  useEffect(() => {
    return () => {
      if (abortControllerRef.current) {
        abortControllerRef.current.abort();
      }
    };
  }, []);

  const clearAll = useCallback(() => {
    if (abortControllerRef.current) {
      abortControllerRef.current.abort();
      abortControllerRef.current = null;
    }
    // Clean memory securely
    setCookieInput('');
    setRefreshedCookie('');
    setStatus('idle');
    setError(null);
    setDetails(null);
    setRateLimitNotice(null);
    setStatusText(null);
    if (onNotify) {
      onNotify('info', 'Dikosongkan', 'Input dan data cookie telah dibersihkan.');
    }
  }, [onNotify]);

  const submitRefresh = useCallback(async (): Promise<boolean> => {
    // 1. Validation
    const validation = validateCookie(cookieInput);
    if (!validation.isValid) {
      const validationError: AppError = {
        code: 'VALIDATION_ERROR',
        message: validation.errorMessage || 'Format cookie tidak valid.'
      };
      setError(validationError);
      setStatus('error');
      if (onNotify) {
        onNotify('warning', 'Perhatian', validationError.message);
      }
      return false;
    }

    // 2. Prevent duplicate submissions
    if (status === 'loading') {
      return false;
    }

    // 3. Setup AbortController
    if (abortControllerRef.current) {
      abortControllerRef.current.abort();
    }
    const controller = new AbortController();
    abortControllerRef.current = controller;

    setStatus('loading');
    setError(null);
    setRefreshedCookie('');
    setDetails(null);
    setRateLimitNotice(null);
    setStatusText(null);

    try {
      const response = await refresherApi.refresh(
        {
          cookie: validation.sanitizedCookie,
          logoutAll,
          detailed: mode === 'detailed'
        },
        (notice, text, intermediateCookie) => {
          setRateLimitNotice(notice);
          if (text) {
            setStatusText(text);
          }
          if (intermediateCookie) {
            setRefreshedCookie(intermediateCookie);
          }
        },
        controller.signal
      );

      if (response.success && response.cookie) {
        setRefreshedCookie(response.cookie);
        setStatus('success');
        if (response.details) {
          setDetails(response.details);
        }
        if (onNotify) {
          onNotify('success', 'Berhasil', 'Cookie .ROBLOSECURITY berhasil diperbarui.');
        }
        return true;
      } else {
        const failureError: AppError = {
          code: 'REFRESH_UNSUCCESSFUL',
          message: response.message || 'Gagal memperbarui cookie.'
        };
        setError(failureError);
        setStatus('error');
        if (onNotify) {
          onNotify('error', 'Gagal', failureError.message);
        }
        return false;
      }
    } catch (err: unknown) {
      const appErr = err as AppError;
      setError(appErr);
      setStatus('error');
      if (onNotify) {
        onNotify('error', 'Gagal', appErr.message || 'Terjadi kesalahan saat memperbarui cookie.');
      }
      return false;
    } finally {
      setRateLimitNotice(null);
      abortControllerRef.current = null;
    }
  }, [cookieInput, logoutAll, mode, status, onNotify]);

  return {
    cookieInput,
    setCookieInput,
    refreshedCookie,
    logoutAll,
    setLogoutAll,
    mode,
    setMode,
    isLoading: status === 'loading',
    status,
    error,
    details,
    rateLimitNotice,
    statusText,
    submitRefresh,
    clearAll
  };
}
