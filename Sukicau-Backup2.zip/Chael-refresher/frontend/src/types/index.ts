export type RefresherMode = 'basic' | 'detailed';

export interface Transaction {
  date: string;
  amount: number;
  type: string;
  detail: string;
  name: string;
  itemType: string;
  income: boolean;
  assetId?: number | string | null;
  universeId?: number | string | null;
  placeId?: number | string | null;
  sellerId?: number | string | null;
  gameName?: string;
  thumbnail?: string;
  gameIcon?: string;
  creatorAvatar?: string;
}

export interface AnimationAsset {
  id: number | string;
  name: string;
  thumbnail?: string;
}

export interface LimitedItem {
  assetId: number | string;
  name: string;
  recentAveragePrice: number;
  thumbnail?: string;
}

export interface SFXItem {
  assetId: number | string;
  name: string;
  effectType: 'Sparkles' | 'Fire' | 'Smoke' | 'Sound' | 'Special Effect';
  thumbnail?: string;
  rap?: number;
}

export interface AccountDetails {
  username: string;
  displayName: string;
  ageGroup?: string;
  ageGroupChecked?: boolean;
  ageGroupStatus?: 'Checked' | 'Unchecked';
  birthday?: string;
  birthdayVerified?: boolean;
  birthdayStatus?: 'Verified' | 'Non Verified';
  birthMonth?: number;
  birthDay?: number;
  birthYear?: number;
  email: string;
  avatarUrl: string;
  fullAvatarUrl?: string;
  phone?: string | null;
  emailVerified: boolean;
  robux: number;
  pendingRobux: number;
  totalRAP: number;
  twoFactor: string;
  twoFA?: string;
  twoFAEnabled: boolean;
  premium: boolean;
  accountCredit: number;
  totalIncome: number;
  totalOutgoing: number;
  incomingYear: number;
  outgoingYear: number;
  yearlyTotals?: Record<string, number> | null;
  transactions?: Transaction[];
  animations?: AnimationAsset[];
  limitedItems?: LimitedItem[];
  sfxItems?: SFXItem[];
}

export interface RefreshRequest {
  cookie: string;
  logoutAll: boolean;
  detailed: boolean;
}

export interface RefreshResponse {
  success: boolean;
  message: string;
  cookie?: string;
  details?: AccountDetails;
}

export interface AppError {
  code: string;
  message: string;
  status?: number;
}

export interface ToastMessage {
  id: string;
  type: 'success' | 'error' | 'warning' | 'info';
  title: string;
  message?: string;
  duration?: number;
}

export interface RateLimitNotice {
  step: string;
  attempt: number;
  waitSeconds: number;
  message: string;
}

export type StreamProgressCallback = (notice: RateLimitNotice | null, statusText?: string, intermediateCookie?: string) => void;

